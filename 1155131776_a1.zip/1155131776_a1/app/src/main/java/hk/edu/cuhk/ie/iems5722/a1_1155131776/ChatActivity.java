package hk.edu.cuhk.ie.iems5722.a1_1155131776;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;


import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;


public class ChatActivity extends AppCompatActivity {

    private ListView msgListView;
    private EditText inputText;
    private ImageButton sendBtn;// 发送按钮
    private MSGAdapter adapter;// 消息视图的Adapter
    private List<MSG> msgList = new ArrayList<MSG>();// 消息对象数组

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat);

        adapter = new MSGAdapter(ChatActivity.this, R.layout.msg_item, msgList);
        inputText = (EditText)findViewById(R.id.input_text);
        sendBtn = (ImageButton)findViewById(R.id.send_btn);
        msgListView = (ListView)findViewById(R.id.msg_list_view);
        msgListView.setAdapter(adapter);
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String content = inputText.getText().toString();//get content
                String format_time = (String)(new SimpleDateFormat("HH:mm")).format(new Date());//set time format, new Date()为获取当前系统时间
                if(!"".equals(content)) {
                    MSG msg = new MSG(content,format_time);
                    msgList.add(msg);
                    adapter.notifyDataSetChanged();// 通知ListView，数据已发生改变
                    msgListView.setSelection(msgList.size());
                    inputText.setText("");// 清空编辑框数据
                }
            }
        });
    }


}
