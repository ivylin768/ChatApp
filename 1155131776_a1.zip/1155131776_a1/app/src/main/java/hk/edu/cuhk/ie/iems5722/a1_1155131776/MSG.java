package hk.edu.cuhk.ie.iems5722.a1_1155131776;


public class MSG {
    private String content;//消息内容
    private String time;//消息日期

    public MSG (String content, String time) {
        this.content = content;
        this.time = time;
    }

    public String getContent() {
        return content;
    }

    public String getDate() {
        return time;
    }

}
