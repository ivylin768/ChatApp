package hk.edu.cuhk.ie.iems5722.a1_1155131776;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.util.List;


public class MSGAdapter extends ArrayAdapter<MSG> {

    private int resId;

    public MSGAdapter(Context context, int textViewResId, List<MSG> objects) {
        super(context, textViewResId, objects);
        resId = textViewResId;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        MSG msg = getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resId, null);
            viewHolder = new ViewHolder();
            viewHolder.rightLayout = (RelativeLayout)view.findViewById(R.id.right_layout);
            viewHolder.content = (TextView)view.findViewById(R.id.right_content);
            viewHolder.time = (TextView)view.findViewById(R.id.time);
            view.setTag(viewHolder);
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }

        //viewHolder.rightLayout.setVisility(View.VISIBLE);
        viewHolder.content.setText(msg.getContent());
        viewHolder.time.setText(msg.getDate());

        return view;

    }

    class ViewHolder {
        RelativeLayout rightLayout;
        TextView content;
        TextView time;
    }

}
