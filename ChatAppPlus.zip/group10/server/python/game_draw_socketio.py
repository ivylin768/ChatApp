from flask import Flask, render_template, request, jsonify, g
from flask_socketio import SocketIO, emit, join_room, leave_room
import logging
import redis


logger = logging.getLogger()
logger.setLevel('DEBUG')
BASIC_FORMAT = "%(asctime)s:%(levelname)s:%(message)s"
DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
formatter = logging.Formatter(BASIC_FORMAT, DATE_FORMAT)
chlr = logging.StreamHandler()
chlr.setFormatter(formatter)
# fhlr = logging.FileHandler('logs/new.log') # 输出到文件的handler
# fhlr.setFormatter(formatter)
logger.addHandler(chlr)
# logger.addHandler(fhlr)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'iems5722'
socketio = SocketIO(app)
redisip = "localhost"


@socketio.on("connect_n")
def connect_handler(data):
    user_id = data['user_id']
    logging.info("{} connect success".format(user_id))


@socketio.on("disconnect_n")
def disconnect_handler(data):
    user_id = data['user_id']
    logging.info("{} disconnect success".format(user_id))


@app.route("/api/project/draw/so/broadcast_position", methods=["POST"])
def broadcast_position():
    try:
        data = request.form.get("data")
        logging.info("received broadcast position request")
        socketio.emit("update_position", {"data":data}, broadcast=True)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"message":str(e), "status": "ERROR"})


@app.route("/api/project/draw/so/game_status", methods=["POST"])
def broadcast_game_status():
    try:
        data = request.form.get("draw_play_status")
        logging.info("received broadcast game status request")
        logging.info(data)
        socketio.emit("update_game_status", {"data":data}, broadcast=True)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"message":str(e), "status": "ERROR"})


@app.route("/api/project/draw/so/draw_line", methods=["POST"])
def broadcast_draw_line():
    try:
        data = request.form.get("trace")
        logging.info("received broadcast draw line request")
        logging.info(data)
        socketio.emit("update_canvas", {"data":data}, broadcast=True)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"message":str(e), "status": "ERROR"})


@app.route("/api/project/draw/so/broadcast_message", methods=["POST"])
def broadcast_message():
    try:
        data = request.form.get("data")
        logging.info("received broadcast message request")
        logging.info(data)
        socketio.emit("update_message", {"data": data}, broadcast=True)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"message": str(e), "status": "ERROR"})


@app.route("/api/project/draw/so/game_result", methods=["POST"])
def broadcast_game_result():
    try:
        data = request.form.get("data")
        logging.info("received broadcast game status request")
        logging.info(data)
        socketio.emit("update_game_result", {"data":data}, broadcast=True)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"message":str(e), "status": "ERROR"})


if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=8007)