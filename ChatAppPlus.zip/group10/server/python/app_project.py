from flask import Flask
from flask import jsonify
from flask import request
from flask import g
import requests
import random
import pymysql
import logging
import math
import redis
import bcrypt
import base64
from datetime import datetime
from send_email import EmailSender

app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)
nums_per_page = 5
redisip = "localhost"
mysqlip = "localhost"

class MyDatabase:
    db = None

    def __init__(self):
        self.connect()
        return

    def connect(self):
        self.db = pymysql.connect(
            host=mysqlip,
            port=3306,
            user='xiaxin',
            passwd='xiaxin',
            db='chat',
            use_unicode=True,
            charset='utf8',
        )
        return

@app.before_request
def before_request():
    g.mydb = MyDatabase()
    g.r = redis.StrictRedis(host=redisip, port=6379, db=1, decode_responses=True, password="liuxiaxin")
    return


@app.teardown_request
def teardown_request(exception):
    mydb = getattr(g, 'mydb', None)
    if mydb is not None:
        mydb.db.close()
    return


@app.route('/')
def hello_world():
    return "hello world!"


#######################################################################################
#######################################################################################
####################                    ###############################################
####################    assignment 3    ###############################################
####################                    ###############################################
#######################################################################################
#######################################################################################

@app.route('/api/a3/get_chatrooms', methods=['GET'])
def get_chatrooms():
    try:
        sql = "select * from chatrooms order by id"
        cursor = g.mydb.db.cursor()
        cursor.execute(sql)
        rooms = cursor.fetchall()
        res = []
        for t in rooms:
            dic = {'id': t[0], 'name': t[1]}
            res.append(dic)
        output = {"data": res, "status": 'OK'}

    except Exception as e:
        logging.error(e)
        output = {"message":str(e), "status": 'ERROR'}
    logging.debug(output)
    return jsonify(output)


@app.route('/api/a3/get_messages', methods=['GET'])
def get_messages():
    try:
        try:
            chatroom_id = int(request.args.get('chatroom_id'))
            page = int(request.args.get('page'))
        except Exception as e:
            logging.error(e)
            return jsonify({"message": "incorrect parameters. "+ str(e), "status": "ERROR"})
        cursor = g.mydb.db.cursor()
        sql_count = "select count(*) from messages where chatroom_id=%s" % chatroom_id
        cursor.execute(sql_count)
        totalpages = math.ceil(cursor.fetchone()[0] / nums_per_page)
        sql = "select * from messages where chatroom_id=%s " \
              "order by id desc limit %s offset %s" % (chatroom_id, nums_per_page, (page-1)*nums_per_page)
        cursor.execute(sql)
        all_messages = cursor.fetchall()
        res = []
        for m in all_messages:
            dic = {'message': m[4], 'name': m[3],'message_time': m[5], 'user_id': m[2]}
            res.append(dic)
        res = res[::-1]
        data = {'current_page': page, "messages":res, 'total_pages': totalpages}
        output = ({"data": data, 'status': "OK"})
    except Exception as e:
        logging.error(e)
        output = {"message": str(e), "status": "ERROR"}
    logging.debug(output)
    return jsonify(output)


@app.route('/api/a3/send_message', methods=['POST'])
def send_message():
    try:
        try:
            chatroom_id = request.form.get("chatroom_id")
            user_id = int(request.form.get("user_id"))
            name = request.form.get("name")
            message = request.form.get("message")
            logging.debug("chatroom_id: "+ chatroom_id+", message: "+message)
        except Exception as e:
            logging.error(e)
            return jsonify({"message": "incorrect parameters. "+ str(e), "status": "ERROR"})
        if None in (chatroom_id, user_id, name, message):
            return jsonify({"message": "incorrect parameters. ", "status": "ERROR"})

        t = datetime.now().strftime("%Y/%m/%d %H:%M")

        sql = "insert into messages (chatroom_id, user_id, username, text, time) values" \
              "(%s, %s, '%s', '%s', '%s')" % (chatroom_id, user_id, name, message, t)

        g.mydb.db.cursor().execute(sql)
        g.mydb.db.commit()
        output = {'status': "OK"}
        r = requests.post("http://localhost:8002/api/a4/broadcast_room", data={"chatroom_id":chatroom_id, "message":message})
                                                  
        logging.info(r.text)
        logging.debug('status:ok')
    except Exception as e:
        logging.error(e)
        output = {"message": str(e), "status": "ERROR"}
    return jsonify(output)



#######################################################################################
#######################################################################################
####################                    ###############################################
####################    project login   ###############################################
####################                    ###############################################
#######################################################################################
#######################################################################################


@app.route("/api/project/login", methods=['POST'])
def login():
    # output = { data = {"find":True, "user_id": 123, "user_name": liuxiaxin, "photoid":1},
    #            status: "OK"}
    try:
        email = request.form.get("email")
        password = request.form.get("password").encode("utf-8")
        sql = '''select user_id, password, username, photoid from user where email_address="{}"'''.format(email)
        cursor = g.mydb.db.cursor()
        cursor.execute(sql)
        users = cursor.fetchall()
        if len(users) == 0:
            output = {"data": {"find": False}, "status":"OK"}
        else:
            user = users[0]
            sv_passwd = base64.b64decode(eval(user[1]))
            if not bcrypt.checkpw(password, sv_passwd):
                output = {"data": {"find": False}, "status": "OK"}
            else:
                data = {"find": True, "user_id": user[0], "user_name": user[2], "photoid": user[3]}
                output = {"data": data, "status": "OK"}
    except Exception as e:
        logging.error(e)
        output = {"message": str(e), "status": "ERROR"}
    logging.debug(output)
    return jsonify(output)

@app.route("/api/project/signup", methods=["POST"])
def signup():
    try:
        email = request.form.get("email")
        password = request.form.get("password")
        name = request.form.get("name")
        photoid = request.form.get("photoid")
        authcode = request.form.get("authcode")

        bcry_passwd = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(14))
        bcry_passwd = str(base64.b64encode(bcry_passwd))
        logging.info(bcry_passwd)
        logging.info(type(bcry_passwd))
        logging.info("input: email {}, authcode {}".format(email, authcode))
        cursor = g.mydb.db.cursor()

        # check email address
        sql = '''select * from user where email_address = "{}"'''.format(email)
        cursor.execute(sql)
        users = cursor.fetchall()
        if len(users) != 0:
            output = {"message":"exists", "status": "ERROR"}
            return jsonify(output)

        # check auth code
        sql = '''select * from auth_tmp where email = "{}" order by time desc limit 1'''.format(email)
        cursor.execute(sql)
        records = cursor.fetchall()
        if len(records) == 0:
            output = {"message":"wrong", "status": "ERROR"}
            logging.debug("no email auth record")
            return jsonify(output)
        record = records[0]
        number = record[1]
        t1 = record[2]
        t2 = datetime.now()
        delta = (t2 - t1).seconds//60
        if delta >= 10:
            output = {"message":"wrong", "status": "ERROR"}
            logging.debug("email auth code expired")
            return jsonify(output)
        if int(number) != int(authcode):
            output = {"message":"wrong", "status": "ERROR"}
            logging.debug("number not equal")
            return jsonify(output)

        # insert
        sql = """insert into user (email_address, password, username, photoid) values
         ('%s', "%s", '%s', '%s')""" % (email, bcry_passwd, name, photoid)
        logging.info(sql)
        g.mydb.db.cursor().execute(sql)
        g.mydb.db.commit()
        
        # get id
        sql = '''select user_id from user where email_address="{}" and password="{}"'''.format(email, bcry_passwd)
        cursor = g.mydb.db.cursor()
        cursor.execute(sql)
        users = cursor.fetchall()
        user_id = users[0][0]

        logging.debug("userid {}, email {}, name {} success insert".format(user_id, email, name))
        return jsonify({"message":user_id, 'status': "OK"})
    except Exception as e:
        logging.error(e)
        output = {"message": str(e), "status": "ERROR"}
        return jsonify(output)


@app.route("/api/project/authcode", methods=["POST"])
def authcode():
    try:
        email = request.form.get("email")
        authcode = random.randint(1000, 9999)
        t = datetime.now().strftime("%Y/%m/%d %H:%M:%S")

        logging.info("input: email {}, authcode {}, t {}".format(email, authcode, t))

        sql = "insert into auth_tmp (email, number, time) values" \
              "('%s', %s, '%s')" % (email, authcode, t)

        g.mydb.db.cursor().execute(sql)
        g.mydb.db.commit()
        es = EmailSender()
        message = es.write_email(email, "auth code for iems5722", "auth code is {}, expired in 10 mins.".format(authcode))
        send_res = es.send_email(message, email)
        logging.info(send_res)
        return jsonify({"status":"OK"})
    except Exception as e:
        logging.error(e)
        output = {"message": str(e), "status": "ERROR"}
        return jsonify(output)

#######################################################################################
#######################################################################################
####################                    ###############################################
#################### project tictactoe  ###############################################
####################                    ###############################################
#######################################################################################
#######################################################################################

def reshape_list(l):
    res=[l[0:3], l[3:6], l[6:9]]
    return res


@app.route("/api/project/tictactoe/route/get_table", methods=['GET'])
def get_table():
    try:
        sit_status = [
            [g.r.get("t00"), g.r.get("t01")],
            [g.r.get("t10"), g.r.get("t11")],
            [g.r.get("t20"), g.r.get("t21")]
        ]

        sit_usr = g.r.lrange("sit", 0, g.r.llen("sit"))

        # 0: not in play, 1: wait for left, 2: wait for right
        play_status = [g.r.get("t0_play"), g.r.get("t1_play"), g.r.get("t2_play")]

        chessboard0 = reshape_list(g.r.lrange("chessboard0", 0, g.r.llen("chessboard0")))
        chessboard1 = reshape_list(g.r.lrange("chessboard1", 0, g.r.llen("chessboard1")))
        chessboard2 = reshape_list(g.r.lrange("chessboard2", 0, g.r.llen("chessboard2")))
        chessboard = [chessboard0, chessboard1, chessboard2]

        table_status = [check_win(chessboard0), check_win(chessboard1), check_win(chessboard2)]

        data = {
            "sit_status":sit_status,
            "sit_usr":sit_usr,
            "play_status":play_status,
            "chessboard":chessboard,
            "table_status":table_status
        }
        logging.info(data)
        return jsonify({"data":data, "status":"OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


def check_win(cb):
    cb = [[int(c) for c in r] for r in cb]

    res = -1

    # row
    if any([r == [1, 1, 1] for r in cb]):
        res = 1
    elif any([r == [2, 2, 2] for r in cb]):
        res = 2

    # col
    elif any([[r[i] for r in cb] == [1, 1, 1] for i in range(3)]):
        res = 1
    elif any([[r[i] for r in cb] == [2, 2, 2] for i in range(3)]):
        res = 2

    # diagnoal
    elif [cb[0][0], cb[1][1], cb[2][2]] == [1, 1, 1] or [cb[2][0], cb[1][1], cb[1][2]] == [1, 1, 1]:
        res = 1
    elif [cb[0][0], cb[1][1], cb[2][2]] == [2, 2, 2] or [cb[2][0], cb[1][1], cb[1][2]] == [2, 2, 2]:
        res = 2

    # contains zero
    elif not any([0 in r for r in cb]):
        res = 0
    return res


@app.route("/api/project/tictactoe/route/sit_table", methods=["POST"])
def sit_table():
    try:
        table_id = request.form.get("table_id")
        pos_id = request.form.get("pos_id")
        user_id = request.form.get("user_id")
        user_name = request.form.get("user_name")
        logging.debug("{} sit in the table {} in pos {}".format(user_name, table_id, pos_id))

        pos = "t{}{}".format(table_id, pos_id)
        if g.r.get(pos) == '-1' and (g.r.llen("sit")==0 or user_name not in g.r.lrange("sit", 0, g.r.llen("sit"))):
            g.r.set(pos,  user_name)
            g.r.rpush("sit", user_name)
            logging.info(pos + user_name)
            data = [
                [g.r.get("t00"), g.r.get("t01")],
                [g.r.get("t10"), g.r.get("t11")],
                [g.r.get("t20"), g.r.get("t21")]
            ]
            logging.info(data)
            r = requests.post("http://localhost:8003/api/project/tictactoe/so/broadcast_table",
                              data={"data":"{} sit table {}".format(user_name, table_id)})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        else:
            return jsonify({"data":"Someone sit here", "status":'ERROR'})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/tictactoe/route/leave_table", methods=["POST"])
def leave_table():
    try:
        table_id = request.form.get("table_id")
        pos_id = request.form.get("pos_id")
        user_id = request.form.get("user_id")
        user_name = request.form.get("user_name")
        logging.debug("{} sit in the table {} in pos {}".format(user_name, table_id, pos_id))

        pos = "t{}{}".format(table_id, pos_id)
        game_status = int(g.r.get("t{}_play".format(table_id)))
        logging.debug("game_status: {}, pos: {}".format(game_status, g.r.get(pos)))
        if game_status == 0 and g.r.get(pos) == user_name:
            g.r.set(pos,  "-1")
            g.r.lrem("sit", 0, user_name)
            r = requests.post("http://localhost:8003/api/project/tictactoe/so/broadcast_table",
                              data={"data":"{} leave table {}".format(user_name, table_id)})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        elif game_status != 0:
            return jsonify({"data": "End game first.", "status":"ERROR"})
        else:
            return jsonify({"data":"Not sit here.", "status":'ERROR'})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/tictactoe/route/start_game", methods=["POST"])
def start_game_ttt():
    table_id = request.form.get("table_id")
    game_status = int(g.r.get("t{}_play".format(table_id)))
    num = int(g.r.get("t{}0".format(table_id)) != '-1') + int(g.r.get("t{}1".format(table_id)) != '-1')
    try:
        if game_status == 0 and num == 2:
            g.r.set("t{}_play".format(table_id), 1)
            r = requests.post("http://localhost:8003/api/project/tictactoe/so/broadcast_table",
                              data={"data":table_id})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        elif num != 2:
            return jsonify({"data": "Not enough people", "status": "ERROR"})
        else:
            return jsonify({"data": "Already started.", "status": "ERROR"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/tictactoe/route/end_game", methods=["POST"])
def end_game_ttt():
    table_id = request.form.get("table_id")
    chessboard_name = "chessboard{}".format(table_id)
    plystatus_name = "t{}_play".format(table_id)
    game_status = int(g.r.get(plystatus_name))
    try:
        if game_status != 0:
            g.r.set(plystatus_name, 0)
            res = g.r.delete(chessboard_name)
            logging.info("chessboard: {}, delete result {}".format(chessboard_name, res))
            g.r.rpush("chessboard{}".format(table_id), 0, 0, 0, 0, 0, 0, 0, 0, 0)
            r = requests.post("http://localhost:8003/api/project/tictactoe/so/broadcast_table",
                              data={"data":table_id})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        else:
            return jsonify({"data":"Not in game.", "status": "ERROR"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/tictactoe/route/move_chess", methods=["POST"])
def move_chess():
    try:
        table_id = int(request.form.get("table_id"))
        chess_x = int(request.form.get("chess_x"))
        chess_y = int(request.form.get("chess_y"))
        chess_type = int(request.form.get("chess_type"))

        game_status = int(g.r.get("t{}_play".format(table_id)))
        logging.info("game_status:")
        logging.info(game_status)
        if game_status != 0:
            chess_board_id = "chessboard{}".format(table_id)
            pos = 3*chess_x+chess_y
            g.r.lset(chess_board_id, pos, chess_type)
            new_status = 1 if game_status == 2 else 2
            g.r.set("t{}_play".format(table_id), new_status)
            logging.info("new_status: "+g.r.get("t{}_play".format(table_id)))
            r = requests.post("http://localhost:8003/api/project/tictactoe/so/broadcast_table",
                              data={"data":table_id})
            logging.info(r.text)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})



#######################################################################################
#######################################################################################
####################                    ###############################################
#################### project draw       ###############################################
####################                    ###############################################
#######################################################################################
#######################################################################################


words = [
    "airplane", "cherry", "diving board", "bus", "calandar", "firetruck", "radio", "store", "saw", "yoga","bike", "cactus"
]


@app.route("/api/project/draw/route/get_position", methods=['GET'])
def get_position():
    try:
        sit_status = [g.r.get("draw_pos0"), g.r.get("draw_pos1"), g.r.get("draw_pos2"), g.r.get("draw_pos3")]
        data = {
            "sit_status": sit_status,
        }
        logging.info(data)
        return jsonify({"data":data, "status":"OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/get_game_status", methods=['GET'])
def get_game_status():
    try:
        game_status = int(g.r.get("draw_play_status"))
        data = {
            "game_status": game_status,
        }
        logging.info(data)
        return jsonify({"data":data, "status":"OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/sit_position", methods=["POST"])
def sit_position():
    try:
        pos_id = request.form.get("pos_id")
        user_id = request.form.get("user_id")
        user_name = request.form.get("user_name")
        logging.info("{} sit in pos {}".format(user_name, pos_id))

        pos = "draw_pos{}".format(pos_id)
        if g.r.get(pos) == '-1' and (g.r.llen("draw_sit")==0 or user_name not in g.r.lrange("draw_sit", 0, g.r.llen("draw_sit"))):
            g.r.set(pos,  user_name)
            g.r.rpush("draw_sit", user_name)
            logging.info(pos + user_name)
            data = [g.r.get("draw_pos0"), g.r.get("draw_pos1"), g.r.get("draw_pos2"), g.r.get("draw_pos3")]
            logging.info(data)
            r = requests.post("http://localhost:8007/api/project/draw/so/broadcast_position",
                              data={"data":data})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        else:
            return jsonify({"data":"Someone sit here", "status":'ERROR'})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/leave_position", methods=["POST"])
def leave_position():
    try:
        pos_id = request.form.get("pos_id")
        user_id = request.form.get("user_id")
        user_name = request.form.get("user_name")
        logging.info("{} leave in pos {}".format(user_name, pos_id))

        pos = "draw_pos{}".format(pos_id)
        game_status = int(g.r.get("draw_play_status"))
        logging.info("game_status: {}, pos: {}".format(game_status, g.r.get(pos)))
        if game_status == 0 and g.r.get(pos) == user_name:
            g.r.set(pos,  "-1")
            g.r.lrem("draw_sit", 0, user_name)
            data = [g.r.get("draw_pos0"), g.r.get("draw_pos1"), g.r.get("draw_pos2"), g.r.get("draw_pos3")]
            logging.info(data)
            r = requests.post("http://localhost:8007/api/project/draw/so/broadcast_position",
                              data={"data":data})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        elif game_status != 0:
            return jsonify({"data": "Still in game.", "status":"ERROR"})
        else:
            return jsonify({"data":"Not sit here.", "status":'ERROR'})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/start_game", methods=["GET"])
def start_game_draw():
    game_status = int(g.r.get("draw_play_status"))
    try:
        if game_status == 0:
            logging.info("get_start_game_request")
            g.r.set("draw_play_status", 1)
            r = requests.post("http://localhost:8007/api/project/draw/so/game_status",
                              data={"draw_play_status": 1})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        else:
            return jsonify({"data": "Already started.", "status": "ERROR"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/end_game", methods=["GET"])
def end_game_draw():
    try:
        logging.info("get end game request")
        # user position
        g.r.set("draw_pos0", "-1")
        g.r.set("draw_pos1", "-1")
        g.r.set("draw_pos2", "-1")
        g.r.set("draw_pos3", "-1")

        # users
        g.r.delete("draw_sit")

        # play status
        g.r.set("draw_play_status", 0)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/draw_line", methods=["POST"])
def draw_line():
    trace = request.form.get("trace")
    try:
        logging.info("get draw line request")
        r = requests.post("http://localhost:8007/api/project/draw/so/draw_line",
                          data={"trace":trace})
        logging.info(r.text)
        return jsonify({"status": "OK"})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/get_word", methods=["GET"])
def get_word():
    try:
        word = random.sample(words, 1)[0]
        logging.info("select word {}".format(word))
        g.r.set("guessword", word)
        return jsonify({"status": "OK", "data":word})
    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


@app.route("/api/project/draw/route/guess_word", methods=["POST"])
def guess_word():
    word = request.form.get("word")
    user_name = request.form.get("user_name")
    real_word = g.r.get("guessword")
    try:
        logging.info("get draw line request")
        logging.info("real word {}, {} guess {}".format(real_word, user_name, word))

        if word != real_word:
            logging.info("guess wrong")
            r = requests.post("http://localhost:8007/api/project/draw/so/broadcast_message",
                              data={"data":"[Wrong] {}: {}".format(user_name, word)})
            logging.info(r.text)
            return jsonify({"status": "OK"})
        else:
            logging.info("guess right, game over")
            r = requests.post("http://localhost:8007/api/project/draw/so/game_result",
                              data={"data":"[Right] {}:{}".format(user_name, word)})  # 2: some one get the right anwser
            logging.info(r.text)
            return jsonify({"status": "OK"})

    except Exception as e:
        logging.error(e)
        return jsonify({"data": str(e), "status": "ERROR"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8001, debug=True)
