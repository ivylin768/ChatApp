import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage


# constants
MailHost = "smtp.gmail.com"
MailUser = 'lx181005@gmail.com'
# MailPass = 'WYKYEKSJIZTCWZUP'
# MailPass = 'LOSIGZYPONWURYNB'  # AWS
Sender = 'lx181005@gmail.com'
password = "GShinhwa"


class EmailSender():
    def __init__(self):
        pass

    @ staticmethod
    def write_email(receiver, subject, text):
        # 设置email信息
        # 邮件内容设置
        message = MIMEMultipart()
        message['Subject'] = subject
        message['From'] = Sender
        message['To'] = receiver

        texts = MIMEText(text, 'plain', 'utf-8')
        message.attach(texts)
        return message

    @ staticmethod
    def send_email(message, receiver):
        # 登录并发送邮件
        try:
            print("reached here")
            smtpObj = smtplib.SMTP()
            smtpObj.connect(MailHost, 587)
            smtpObj.ehlo()
            smtpObj.starttls()
            smtpObj.login(MailUser, password)
            #发送
            smtpObj.sendmail(Sender, receiver, message.as_string())
            smtpObj.quit()
            print("email send success")
            return 'email send success'
        except smtplib.SMTPException as e:
            print(e)
            return 'error ' + e


if __name__ == "__main__":
    es = EmailSender()
    email = "liuxx1995@126.com"
    authcode = 1234
    message = es.write_email(email, "auth code for iems5722", "auth code is {}, expired in 10 mins.".format(authcode))
    send_res = es.send_email(message, email)