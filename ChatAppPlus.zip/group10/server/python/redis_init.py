import redis

r = redis.StrictRedis(host="localhost", port=6379, db=1,decode_responses=True, password="liuxiaxin")


## draw

# user position
r.set("draw_pos0", "-1")
r.set("draw_pos1", "-1")
r.set("draw_pos2", "-1")
r.set("draw_pos3", "-1")

# users

r.delete("draw_sit")

# play status
r.set("draw_play_status", 0)




## ttt

# sit status
r.set("t00", "-1")
r.set("t01", "-1")
r.set("t10", "-1")
r.set("t11", "-1")
r.set("t20", "-1")
r.set("t21", "-1")


# sit user
r.delete("sit")


# play status
r.set("t0_play", 0)
r.set("t1_play", 0)
r.set("t2_play", 0)

# chessboard status
r.delete("chessboard0")
r.delete("chessboard1")
r.delete("chessboard2")

r.rpush("chessboard0", 0, 0, 0, 0, 0, 0, 0, 0, 0)
r.rpush("chessboard1", 0, 0, 0, 0, 0, 0, 0, 0, 0)
r.rpush("chessboard2", 0, 0, 0, 0, 0, 0, 0, 0, 0)