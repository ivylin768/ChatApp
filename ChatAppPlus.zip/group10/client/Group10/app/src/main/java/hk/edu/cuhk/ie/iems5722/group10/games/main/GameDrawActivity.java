package hk.edu.cuhk.ie.iems5722.group10.games.main;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import hk.edu.cuhk.ie.iems5722.group10.APIReader;
import hk.edu.cuhk.ie.iems5722.group10.CommonCountDownTimer;
import hk.edu.cuhk.ie.iems5722.group10.MainActivity;
import hk.edu.cuhk.ie.iems5722.group10.MyDialog;
import hk.edu.cuhk.ie.iems5722.group10.R;
import hk.edu.cuhk.ie.iems5722.group10.VolleySingleton;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class GameDrawActivity extends AppCompatActivity {
    private Socket socket;
    RequestQueue queue;

    int user_id=-1;
    String user_name;
    String photo_id;

    int userRole = -1; // init: -1, watch: 0, in-game:1, host:2
    int gameStatus = 0; //init: wait: 0; during the game:1;
    int pos_id = -1; // -1: not in table, 0-3: in the table
    int set_pos_id = -1;

    int numPos = 4;
    Button[] btnArrSit = new Button[numPos];
    Drawable originBtnArrSitDrawable;
    ColorStateList originBtnArrSitColor;
    Button startBtn;
    LinearLayout llvEditText;
    EditText editText;
    LinearLayout llvWord;
    TextView wordText;
    ImageButton btnSend;

    TextView tvShowMessage;
    Button tv_time;
    CommonCountDownTimer mCountDownTimer;

    private ImageView iv;
    private Bitmap baseBitmap;
    private Canvas canvas;
    private Paint paint;

    JSONArray trace = new JSONArray();

    String title = "DRAW SOMETHING";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_draw);
        try {
            user_name = getIntent().getExtras().getString("user_name");
            user_id = getIntent().getExtras().getInt("user_id");
            photo_id = getIntent().getExtras().getString("photot_id");
        } catch (Exception e) {
            Log.d("onCreate", "no info");
        }
        initCountDownTimer();
        initSocketIO();


        initLayout();
        initCanvas();
        queue = VolleySingleton.getInstance(this.getApplicationContext()).
                getRequestQueue();

        // update user positions
        StringRequest initPositionRequest = initPosition();
        queue.add(initPositionRequest);

        setSitButtom();
    }

    private void initSocketIO(){
        String uri = new APIReader().socketio_draw;
        try{
            socket = IO.socket(uri);
            socket.on(Socket.EVENT_CONNECT, onConnectSuccess);
            socket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
            socket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);

            socket.on("update_position", onPositionUpdate);
            socket.on("update_canvas", onCanvasUpdate);
            socket.on("update_game_status", onGameStatusUpdate);
            socket.on("update_message", onMessageUpdate);
            socket.on("update_game_result", onGameResultUpdate);
            socket.connect();
        } catch (URISyntaxException e){
            e.printStackTrace();
        }
        if (socket != null){
            try {
                JSONObject json = new JSONObject();
                json.put("user_id", user_id);
                socket.emit("connect_n", json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    private void initCanvas() {
        iv = (ImageView) findViewById(R.id.draw_iv);

        Drawable iv_drawable = iv.getDrawable();
        int w = (int) iv_drawable.getIntrinsicWidth();
        int h = (int) iv_drawable.getIntrinsicHeight();
        baseBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);

        canvas = new Canvas(baseBitmap);
        canvas.drawColor(getResources().getColor(R.color.field_color));
        paint = new Paint();
        paint.setColor(getResources().getColor(R.color.red_color));

        paint.setStrokeWidth(5);
        canvas.drawBitmap(baseBitmap, new Matrix(), paint);
        iv.setImageBitmap(baseBitmap);
    }

    private void setCanvas(){
        if (gameStatus>0&&pos_id+1==gameStatus){     // turn to draw picture
            iv.setOnTouchListener(new View.OnTouchListener() {
                int startX;
                int startY;

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            startX = (int) event.getX();
                            startY = (int) event.getY();
                            // 获得一个新的trace Array
                            trace = new JSONArray(new ArrayList<String>());
                            JSONArray t1 = new JSONArray();
                            t1.put(startX);
                            t1.put(startY);
                            trace.put(t1);
                            break;
                        case MotionEvent.ACTION_MOVE:
                            int stopX = (int) event.getX();
                            int stopY = (int) event.getY();

                            JSONArray t2 = new JSONArray();
                            t2.put(stopX);
                            t2.put(stopY);
                            trace.put(t2);

                            canvas.drawLine(startX, startY, stopX, stopY, paint);

                            startX = (int) event.getX();
                            startY = (int) event.getY();
                            iv.setImageBitmap(baseBitmap);
                            break;
                        case MotionEvent.ACTION_UP:
                            StringRequest sr = sendDrawLine();
                            queue.add(sr);
                    }
                    return true;
                }
            });
        }
    }

    private void drawALine(String traceStr){
        try{
            JSONArray traceArr = new JSONArray(traceStr);
            int start_x=-1; int start_y=-1;
            for (int x=0; x<traceArr.length(); x++){
                if (start_x==-1){
                    JSONArray t1 = traceArr.getJSONArray(x);
                    start_x = t1.getInt(0);
                    start_y = t1.getInt(1);
                }else{
                    JSONArray t2 = traceArr.getJSONArray(x);
                    int stop_x = t2.getInt(0);
                    int stop_y = t2.getInt(1);
                    canvas.drawLine(start_x, start_y, stop_x, stop_y, paint);
                    iv.setImageBitmap(baseBitmap);
                    start_x = stop_x;
                    start_y = stop_y;
                }
            }
        }catch (JSONException e){
            e.printStackTrace();
        }

    }

    @Override
    protected void onDestroy(){
        if (socket != null){
            socket.disconnect();
            socket.off();
        }
        super.onDestroy();
    }

    @Override
    protected void onStop(){
        if (socket != null){
            socket.disconnect();
            socket.off();
        }
        super.onStop();
    }

    private Emitter.Listener onConnectSuccess = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d("onConnectSuccess" ,"WebSocket successfully connected...");
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            if (args[0] instanceof Throwable) {
                ((Throwable) args[0]).printStackTrace();
            }
            System.out.println("error message" + args[0]);
        }
    };

    private Emitter.Listener onCanvasUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onCanvasUpdate" ,"update canvas status...");
            if (userRole!=2){
                try{
                    JSONObject json = (JSONObject)args[0];
                    final String traceString = json.getString("data");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            drawALine(traceString);
                        }
                    });
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
            }

    };

    private Emitter.Listener onPositionUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onPositionUpdate" ,"update position status...");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    StringRequest initPositionRequest = initPosition();
                    queue.add(initPositionRequest);
                }
            });
        }
    };

    private Emitter.Listener onGameStatusUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onGameStatusUpdate" ,"update gamestatus status...");

            try {

                JSONObject data = (JSONObject)args[0];
                final int status = data.getInt("data");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (gameStatus==0&&status==1){
                            String content = "Game Start";
                            MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                            dialog.show();
                        }
                        gameStatus = status;
                        setStartBtn();
                        setCanvas();
                        setSitButtom();
                        setGameLayout();
                        mCountDownTimer.start();

                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener onMessageUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onMessageUpdate" ,"update message...");
            try {

                JSONObject data = (JSONObject)args[0];
                final String message = data.getString("data");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvShowMessage.setText(message);
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener onGameResultUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onGameResultUpdate" ,"update game result...");
            try {
                JSONObject data = (JSONObject)args[0];
                final String message = data.getString("data");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String content = message;
                        MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content, new MyDialog.OncloseListener() {
                            @Override
                            public void onClick(boolean confirm) {
                                StringRequest endGameRequest = sendEndGame();
                                queue.add(endGameRequest);
                            }
                        });
                        dialog.show();
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private void initLayout(){
        // sit buttom
        btnArrSit[0] = findViewById(R.id.usr1);
        btnArrSit[1] = findViewById(R.id.usr2);
        btnArrSit[2] = findViewById(R.id.usr3);
        btnArrSit[3] = findViewById(R.id.usr4);
        originBtnArrSitDrawable = btnArrSit[0].getBackground();
        originBtnArrSitColor = btnArrSit[0].getTextColors();

        // start game
        startBtn = findViewById(R.id.draw_start);

        // for draw
        llvWord = findViewById(R.id.llword);
        wordText = findViewById(R.id.word);

        // for guess
        llvEditText = findViewById(R.id.inpword);
        editText = findViewById(R.id.etWord);
        btnSend = findViewById(R.id.drawSend);

        tvShowMessage = findViewById(R.id.viewText);
        tv_time = findViewById(R.id.timer);
    }

    private void setSitButtom(){
        for(int x=0;x<numPos;x++){
            final int curr_x = x;
            btnArrSit[x].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (btnArrSit[curr_x].getText().equals(getResources().getString(R.string.free)) && pos_id==-1 && gameStatus==0){
                        set_pos_id = curr_x;
                        StringRequest sr = sendSitPosition();
                        queue.add(sr);
                    } else if (pos_id!=-1 && curr_x==pos_id&&gameStatus==0){
                        StringRequest sr = sendLeavePosition();
                        queue.add(sr);
                    }
                }
            });
        }
    }

    private StringRequest initPosition(){
        final String TAG = "initPosition";
        String MessageURL = String.format(new APIReader().get_position);
        return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    JSONObject data = json.getJSONObject("data");

                    // sit status
                    JSONArray sitArray = data.getJSONArray("sit_status");
                    for (int i=0; i<numPos;i++){
                        String tmp = sitArray.getString(i);
                        if (tmp.equals("-1")){
                            Button bt = btnArrSit[i];
                            bt.setText(R.string.free);
                            bt.setBackground(originBtnArrSitDrawable);
                            bt.setTextColor(originBtnArrSitColor);
                        }else {
                            Button bt = btnArrSit[i];
                            bt.setText(tmp);
                            btnArrSit[i].setTextColor(getResources().getColor(R.color.dark_border_color));
                            if (user_name.equals(tmp)){
                                btnArrSit[i].setBackgroundColor(getResources().getColor(R.color.blue_color));
                            }
                        }
                    }
                    setSitButtom();  // set on click listener
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG,"error in initPosition");
                error.printStackTrace();
            }
        });
    }


    private StringRequest sendSitPosition(){
        final String TAG = "sendSitPosition";

        return new StringRequest(Request.Method.POST, new APIReader().sit_position,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                pos_id = set_pos_id;
                                if (pos_id==0){
                                    userRole = 2;
                                }else{
                                    userRole = 1;
                                }
                                setStartBtn();
                            } else{
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("pos_id",Integer.toString(set_pos_id));
                params.put("user_id",Integer.toString(user_id));
                params.put("user_name",user_name);
                return params;
            }
        };
    }

    private StringRequest sendLeavePosition(){
        final String TAG = "sendLeavePosition";

        return new StringRequest(Request.Method.POST, new APIReader().leave_position,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                System.out.println("leave ok");
                                btnArrSit[pos_id].setBackground(originBtnArrSitDrawable);
                                pos_id = -1;
                            } else{
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("pos_id",Integer.toString(pos_id));
                params.put("user_id",Integer.toString(user_id));
                params.put("user_name",user_name);
                return params;
            }
        };
    }

    private void setStartBtn(){
        if (userRole==2 && gameStatus<=0){
            startBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    StringRequest sr = sendStartGame();
                    queue.add(sr);
                }
            });
        }
        if (gameStatus>0){
            startBtn.setText(R.string.play);
            startBtn.setOnClickListener(null);
        }

    }

    private void setGameLayout(){
        if (userRole==1){ // guess
            llvEditText.setVisibility(View.VISIBLE);
            llvWord.setVisibility(View.GONE);
            btnSend.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String InputContent = editText.getText().toString();
                    if (InputContent.length()!=0) {
                        StringRequest sendMessageRequest = sendGuessWord();
                        queue.add(sendMessageRequest);
                    }
                }
            });
        }else if (userRole == 2){ // draw
            llvWord.setVisibility(View.VISIBLE);
            llvEditText.setVisibility(View.GONE);
            StringRequest getWordRequest = sendGetWord();
            queue.add(getWordRequest);
        }
    }

    private StringRequest sendStartGame(){
            final String TAG = "sendStart";
            String MessageURL = String.format(new APIReader().draw_start_game);
            return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    JSONObject json;
                    String content;
                    try {
                        json = new JSONObject(response);
                        String status = json.getString("status");
                        if (status.equals("OK")){
                            content = "Game Start.";
                        } else{
                            content = json.getString("data");
                        }
                        MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                        dialog.show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.d(TAG,error.toString());
                    error.printStackTrace();
                }
            });
        }

    private StringRequest sendEndGame(){
        final String TAG = "sendEndGame";
        String MessageURL = String.format(new APIReader().draw_end_game);
        return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JSONObject json;
                String content;
                try {
                    json = new JSONObject(response);
                    String status = json.getString("status");
                    if (status.equals("OK")){
                        content = "Game End.";
                    } else{
                        content = json.getString("data");
                    }
                    MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content, new MyDialog.OncloseListener() {
                        @Override
                        public void onClick(boolean confirm) {
                            pos_id=-1;
                            gameStatus=0;
                            tvShowMessage.setText("");
                            initCanvas();
                            StringRequest initPositionRequest = initPosition();
                            queue.add(initPositionRequest);
                            startBtn.setText(getResources().getText(R.string.start));
                            mCountDownTimer.cancel();
                        }
                    });
                    dialog.show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG,error.toString());
                error.printStackTrace();
            }
        });
    }


    private StringRequest sendDrawLine(){
        final String TAG = "sendDrawLine";

        return new StringRequest(Request.Method.POST, new APIReader().draw_line,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                System.out.println("send ok");
                            } else{
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("trace",trace.toString());
                return params;
            }
        };
    }

    private StringRequest sendGetWord(){
        final String TAG = "sendGetWord";
        String MessageURL = String.format(new APIReader().draw_get_word);
        return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                JSONObject json;
                String content;
                try {
                    json = new JSONObject(response);
                    String status = json.getString("status");
                    if (status.equals("OK")){
                        String word = json.getString("data");
                        wordText.setText(word);
                    } else{
                        content = json.getString("data");
                        MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                        dialog.show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG,error.toString());
                error.printStackTrace();
            }
        });
    }

    private StringRequest sendGuessWord(){
        final String TAG = "sendGuessWord";

        return new StringRequest(Request.Method.POST, new APIReader().draw_guess_word,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                editText.setText("");
                                System.out.println("send ok");
                            } else{
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("word",editText.getText().toString());
                params.put("user_name", user_name);
                return params;
            }
        };
    }

    private void initCountDownTimer() {
        mCountDownTimer = new CommonCountDownTimer(60000, 1000);
        mCountDownTimer.setCountDownTimerListener(new CommonCountDownTimer.OnCountDownTimerListener() {
            @Override
            public void onTick(long millisUntilFinished) {
                tv_time.setText(Long.toString(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                String content = "Time end.";
                MyDialog dialog = new MyDialog(GameDrawActivity.this, R.style.mdialog, title, content, new MyDialog.OncloseListener() {
                    @Override
                    public void onClick(boolean confirm) {
                        StringRequest endGameRequest = sendEndGame();
                        queue.add(endGameRequest);
                    }
                });
                dialog.show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(GameDrawActivity.this, MainActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }
}
