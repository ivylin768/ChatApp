package hk.edu.cuhk.ie.iems5722.group10;

public class Chatroom {
    private int chatid;  //chatroom id
    private String chatname; //chatroom name

    public Chatroom(int chatid, String chatname) {
        this.chatid = chatid;
        this.chatname = chatname;
    }

    public int getChatid() {
        return chatid;
    }

    public String getChatname() {
        return chatname;
    }
}
