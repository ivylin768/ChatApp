package hk.edu.cuhk.ie.iems5722.group10;

public interface GetConnection {
    void onFinish(String response); //返回正常
    void onError(Exception e); //返回错误
}
