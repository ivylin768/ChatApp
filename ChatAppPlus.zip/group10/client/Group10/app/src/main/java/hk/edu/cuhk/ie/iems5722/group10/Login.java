package hk.edu.cuhk.ie.iems5722.group10;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    EditText emai1;
    EditText password;
    Button btn;
    RequestQueue queue;

    String sendLoginURL = new APIReader().login;
    public static String user_name;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_account, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        queue = VolleySingleton.getInstance(this.getApplicationContext()).
                getRequestQueue();

        emai1 = (EditText) findViewById(R.id.account_input);
        password = (EditText) findViewById(R.id.password_input);

        btn = (Button)findViewById(R.id.btn_loginlg);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (checkInput(emai1.getText().toString(), password.getText().toString())){
                    StringRequest sr = sendLogin();
                    queue.add(sr);
                }
                else{
                    String title = "Login";
                    String content = "Wrong input, try again.";
                    MyDialog dialog = new MyDialog(Login.this, R.style.mdialog, title, content);
                    dialog.show();
                }
            }
        });
    }

    private boolean checkInput(String emailAddress, String passWord){
        String regex_email = "\\w+@\\w+(\\.\\w{2,3})*\\.\\w{2,3}";
        String regex_password = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$";
        return (emailAddress.matches(regex_email) && passWord.matches(regex_password));
    }

    private StringRequest sendLogin(){
        final String TAG = "sendLogin";

        return new StringRequest(Request.Method.POST, sendLoginURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            JSONObject data = json.getJSONObject("data");  // todo: if status == 'error'
                            Boolean found = data.getBoolean("find");
                            if (found){
                                final int user_id = data.getInt("user_id");
                                user_name = data.getString("user_name");
                                System.out.println("########");
                                System.out.println(user_name);
                                final String photo_id = data.getString("photoid");
                                String title = "Login";
                                String content = "Successfull login.";
                                MyDialog dialog = new MyDialog(Login.this, R.style.mdialog, title, content,
                                        new MyDialog.OncloseListener() {
                                            @Override
                                            public void onClick(boolean confirm) {
                                                Intent intent = new Intent(Login.this, MainActivity.class);
                                                intent.putExtra("user_id", user_id);
                                                intent.putExtra("user_name", user_name);
                                                intent.putExtra("photot_id", photo_id);
                                                startActivity(intent);
                                            }
                                        });
                                dialog.show();
                            }

                            else{
                                String title = "Login";
                                String content = "Wrong account info, try again.";
                                MyDialog dialog = new MyDialog(Login.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email",emai1.getText().toString());
                params.put("password",password.getText().toString());
                return params;
            }
        };
    }

}
