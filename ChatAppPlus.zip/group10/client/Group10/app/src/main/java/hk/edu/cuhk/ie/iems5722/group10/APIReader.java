package hk.edu.cuhk.ie.iems5722.group10;

public class APIReader {
    String host = "http://52.45.191.18";
    public String get_chatrooms = host + "/api/a3/get_chatrooms";
    public String get_messages =  host + "/api/a3/get_messages";
    public String send_message =  host + "/api/a3/send_message";

    public String login =  host + "/api/project/login";
    public String signup =  host + "/api/project/signup";
    public String authcode =  host + "/api/project/authcode";

    // game ttt
    public String socketio_ttt = host+":8003";
    public String get_table = host + "/api/project/tictactoe/route/get_table";
    public String sit_table = host + "/api/project/tictactoe/route/sit_table";
    public String leave_table = host +"/api/project/tictactoe/route/leave_table";
    public String start_game = host + "/api/project/tictactoe/route/start_game";
    public String end_game = host + "/api/project/tictactoe/route/end_game";
    public String move_chess = host + "/api/project/tictactoe/route/move_chess";

    // game draw
    public String socketio_draw = host + ":8007";
    public String draw_getStatus = host+"/api/project/draw/route/get_game_status";
    public String get_position = host + "/api/project/draw/route/get_position";
    public String sit_position = host + "/api/project/draw/route/sit_position";
    public String leave_position = host + "/api/project/draw/route/leave_position";
    public String draw_start_game = host + "/api/project/draw/route/start_game";
    public String draw_end_game = host + "/api/project/draw/route/end_game";
    public String draw_line = host + "/api/project/draw/route/draw_line";
    public String draw_get_word = host + "/api/project/draw/route/get_word";
    public String draw_guess_word = host + "/api/project/draw/route/guess_word";
}
