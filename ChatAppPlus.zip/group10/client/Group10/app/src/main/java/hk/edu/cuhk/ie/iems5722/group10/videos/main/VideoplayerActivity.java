package hk.edu.cuhk.ie.iems5722.group10.videos.main;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import hk.edu.cuhk.ie.iems5722.group10.MainActivity;
import hk.edu.cuhk.ie.iems5722.group10.R;

public class VideoplayerActivity extends AppCompatActivity implements Button.OnClickListener {

    int user_id=-1;
    String user_name;
    String photo_id;

    int click=0;

    private String uri = "http://ips.ifeng.com/video19.ifeng.com/video09/2014/06/16/1989823-102-086-0009.mp4";//打开直接播放某网络视频

    private VideoView videoView;
    private MediaController mMediaController;

    private static final int FILE_SELECT_CODE=1;

    private static final String TAG="VideoplayerActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_player);
        try {
            user_name = getIntent().getExtras().getString("user_name");
            user_id = getIntent().getExtras().getInt("user_id");
            photo_id = getIntent().getExtras().getString("photot_id");
        } catch (Exception e) {
            Log.d("onCreate", "no info");
        }
        videoView = (VideoView) findViewById(R.id.videoView);

        //播放条
        mMediaController = new MediaController(this);

        // VideiView获焦点
        videoView.requestFocus();

        ImageButton start = (ImageButton) findViewById(R.id.start);
        start.setOnClickListener(this);

        ImageButton pause = (ImageButton) findViewById(R.id.pause);
        pause.setOnClickListener(this);

        ImageButton replay = (ImageButton) findViewById(R.id.replay);
        replay.setOnClickListener(this);

        ImageButton file = (ImageButton) findViewById(R.id.file);
        file.setOnClickListener(this);

        ImageButton full = (ImageButton) findViewById(R.id.fullscreen);
        full.setOnClickListener(this);

        if (ContextCompat.checkSelfPermission(VideoplayerActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(VideoplayerActivity.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        } else {
            inintVideoPath();
        }
        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                Log.i("tag", "准备完毕,可以播放了");
            }
        });
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Log.i("tag", "播放完毕");
            }
        });
        videoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                Log.i("tag", "播放失败");
                if (what == 100)
                {
                    videoView.stopPlayback();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }
                else if (what == 1)
                {
                    videoView.stopPlayback();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }
                else if(what == 800)
                {
                    videoView.stopPlayback();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }
                else if (what == 701)
                {
                    videoView.stopPlayback();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }
                else if(what == 700)
                {
                    videoView.stopPlayback();

                    Toast.makeText(getApplicationContext(), "Bad Media format ", Toast.LENGTH_SHORT).show();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }

                else if (what == -38)
                {
                    videoView.stopPlayback();
                    Intent inn = new Intent(VideoplayerActivity.this,VideoplayerActivity.class);
                    startActivity(inn);
                }
                return true;
            }
        });

        //设置videoview的点击事件：点击隐藏播放工具（linearlayout）和播放条，如果已经隐藏则显示
        final LinearLayout play_tools = (LinearLayout) findViewById(R.id.play_tools);
        videoView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if (play_tools.getVisibility() == View.VISIBLE) {

                    mMediaController.hide();
                    play_tools.setVisibility(View.GONE);
                } else {

                    videoView.setMediaController(mMediaController);
                    mMediaController.setAnchorView(videoView);//把MediaController定位在VideoView上
                    play_tools.setVisibility(View.VISIBLE);
                }

                return false;
            }
        });

    }

    private void inintVideoPath() {
        //打开直接播放某网络视频
        videoView.setVideoURI(Uri.parse(uri));//指定网络视频uri
    }

    public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){

        switch (requestCode){

            case 1:
                if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    inintVideoPath();
                } else {
                    Toast.makeText(this,"Deny permission will have no access to this function",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
        }
    }

    @Override
    public void onClick(View v){

        switch (v.getId()){

            case R.id.start:
                if(!videoView.isPlaying()){
//                    videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { //无此直接start报错：E/MediaPlayer: Error (1,-38)
//                        public void onPrepared(MediaPlayer mp) {
                            videoView.start();
//                        }
//                    });
                }
                break;

            case R.id.pause:
                if(videoView.isPlaying()){
                    videoView.pause();
                }
                break;

            case R.id.replay:
                if(videoView != null){
//                    videoView.resume();//重新播放,无效

                    ///method1
//                    videoView.pause();
//                    videoView.stopPlayback();
//                    videoView.setVideoURI(Uri.parse(uri));
//                    videoView.start();

                    ///method2
                    videoView.seekTo(0);
                    videoView.start();
                }
                break;

            case R.id.file:
                Intent intent=new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");//设置类型，这是任意类型
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent,1);
                break;///

            case R.id.fullscreen: //点一次横屏全屏,点第二次竖屏
                click++;
                if(videoView != null) {
                    switch (click) {
                        case 1://第一次点击
                            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置videoView全屏播放
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//设置videoView横屏播放

                            break;

                        case 2://第二次点击
                            click=0;//点击次数重置为0
                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);//设置videoView竖屏播放
//                            WindowManager wm2 = (WindowManager) getSystemService(WINDOW_SERVICE);
//                            android.view.Display display2 = wm2.getDefaultDisplay();
//                            Point point2 = new Point();
//                            int API_LEVEL2 = android.os.Build.VERSION.SDK_INT;
//                            if(API_LEVEL2 >= 17){
//                                display2.getRealSize(point2);
//                            }else{
//                                display2.getSize(point2);
//                            }
//                            int height2 = point2.y;
//                            int width2 = point2.x;
//                            Log.i(TAG,"screenHeight = "+height2+" ; screenWidth = "+width2);
//                            RelativeLayout.LayoutParams layoutParams2 = (RelativeLayout.LayoutParams) videoView
//                                    .getLayoutParams(); // 取控当前的布局参数
//                            layoutParams2.height = height2;
//                            layoutParams2.width = width2;
//                            layoutParams2.setMargins(0,0,0,0);
//                            videoView.setLayoutParams(layoutParams2);
                            break;
                    }

                    //量屏幕尺寸设置videoview的大小
                    WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                    android.view.Display display = wm.getDefaultDisplay();
                    Point point = new Point();
                    int API_LEVEL = android.os.Build.VERSION.SDK_INT;
                    if(API_LEVEL >= 17){
                        display.getRealSize(point);
                    }else{
                        display.getSize(point);
                    }
                    int height = point.y;
                    int width = point.x;
                    Log.i(TAG,"screenHeight = "+height+" ; screenWidth = "+width);
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) videoView
                            .getLayoutParams(); // 取控当前的布局参数
                    layoutParams.height = height;
                    layoutParams.width = width;
                    layoutParams.setMargins(0,0,0,0);
                    videoView.setLayoutParams(layoutParams);

                }
                break;

            default:
                break;
        }
    }

    public void onDestroy(){
        super.onDestroy();
        if(videoView != null){
            videoView.suspend();
            videoView.stopPlayback();
            videoView.setOnErrorListener(null);
            videoView.setOnPreparedListener(null);
            videoView.setOnCompletionListener(null);

            videoView = null;

        }
    }

    //处理选择文件的回调
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        System.out.println("======requestCode");
        System.out.println(requestCode);
        System.out.println(resultCode);

        switch (requestCode) {
            case FILE_SELECT_CODE:
                if(resultCode== Activity.RESULT_OK){
                    uri=data.getData().toString();
                    Log.i(TAG,"------->" + uri);
                    Log.i(TAG,"------->" + Uri.parse(uri).getPath());
                    videoView.setVideoPath(uri); //
                }
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);

    }

    public void onConfigurationChanged(Configuration newConfig) {
        //TODO Auto-generated method stubsuper.onConfigurationChanged(newConfig);
        if (newConfig.orientation==Configuration.ORIENTATION_LANDSCAPE) {
            //Nothing need to be done here
        } else {
            //Nothing need to be done here
        }

        super.onConfigurationChanged(newConfig);
    }

}

