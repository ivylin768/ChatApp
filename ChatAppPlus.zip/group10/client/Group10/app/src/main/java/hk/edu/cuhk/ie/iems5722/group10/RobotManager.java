package hk.edu.cuhk.ie.iems5722.group10;

public class RobotManager {
    private static String url = "http://api.qingyunke.com/api.php?key=free&appid=0&msg=!!";

    public static String newUrl (String message) {
        String final_url = url.replace("!!",message);//将url中的!!替换为用户输入的内容
        return final_url;
    }
}
