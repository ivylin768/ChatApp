package hk.edu.cuhk.ie.iems5722.group10.videos.main;


import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import hk.edu.cuhk.ie.iems5722.group10.ItemProgramAdapter;
import hk.edu.cuhk.ie.iems5722.group10.R;


public class TvliveActivity extends AppCompatActivity {

    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tv_live);
        mListView = (ListView) findViewById(R.id.tv_program);
        mListView.setAdapter(new ItemProgramAdapter(TvliveActivity.this));
    }

}
