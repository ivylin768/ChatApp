package hk.edu.cuhk.ie.iems5722.group10.ui.main;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import hk.edu.cuhk.ie.iems5722.group10.R;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class SectionsPagerAdapter extends FragmentPagerAdapter {

    @StringRes
    private static final int[] TAB_TITLES = new int[]{R.string.tab_text_1, R.string.tab_text_2,R.string.tab_text_3};
    private final Context mContext;
    int user_id;
    String user_name;
    String photo_id;

    public SectionsPagerAdapter(Context context, FragmentManager fm, int usr_id, String usr_name, String phto_id) {
        super(fm);
        mContext = context;
        user_id = usr_id;
        user_name = usr_name;
        photo_id = phto_id;
    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a Fragment (defined as a static inner class below).
        if (position==0) {
            return ChatFragment.newInstance(user_id, user_name, photo_id);
        }else if (position==1){
            return GameFragment.newInstance(user_id, user_name, photo_id);
        }else if (position==2){
            return VideoFragment.newInstance(user_id, user_name, photo_id);
        }
        return ChatFragment.newInstance(user_id, user_name, photo_id);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TAB_TITLES[position]);
    }

    @Override
    public int getCount() {
        // Show 4 total pages.
        return 3;
    }
}