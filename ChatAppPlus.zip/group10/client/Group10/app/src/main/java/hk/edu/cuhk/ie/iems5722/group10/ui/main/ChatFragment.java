package hk.edu.cuhk.ie.iems5722.group10.ui.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import hk.edu.cuhk.ie.iems5722.group10.APIReader;
import hk.edu.cuhk.ie.iems5722.group10.ChatActivity;
import hk.edu.cuhk.ie.iems5722.group10.Chatroom;
import hk.edu.cuhk.ie.iems5722.group10.ChatroomAdapter;
import hk.edu.cuhk.ie.iems5722.group10.HTTP;
import hk.edu.cuhk.ie.iems5722.group10.MainActivity;
import hk.edu.cuhk.ie.iems5722.group10.MyDialog;
import hk.edu.cuhk.ie.iems5722.group10.R;
import hk.edu.cuhk.ie.iems5722.group10.RobotActivity;

/**
 * A placeholder fragment containing a simple view.
 */
public class ChatFragment extends Fragment {

    MainTask mTask;
    private ListView chatroomListView;
    private ChatroomAdapter adapter;
    private List<Integer> idList = new ArrayList<Integer>();//定义一个整数list存放chatroomID
    private List<String> nameList = new ArrayList<>();//定义一个list存放chatroomName
    private List<Chatroom> chatroomList = new ArrayList<>();

    int user_id=-1;
    String user_name;
    String photo_id;

    public static ChatFragment newInstance(int usr_id, String usr_name, String phto_id) {
        ChatFragment fragment = new ChatFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("user_id", usr_id);
        bundle.putString("user_name", usr_name);
        bundle.putString("photo_id", phto_id);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_mchat, container, false);
        Bundle bundle = getArguments();
        user_id = bundle.getInt("user_id");
        user_name = bundle.getString("user_name");
        photo_id = bundle.getString("photo_id");
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        //启动AsyncTask，手动调用execute(Params... params) 从而执行异步线程任务
        mTask = new MainTask();
        mTask.execute(new APIReader().get_chatrooms);

        FloatingActionButton fab = getView().findViewById(R.id.action_robot);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), RobotActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
            }
        });
    }

    //创建AsyncTask子类
    private class MainTask extends AsyncTask<String, Integer, String> {
        //onPreExecute()执行线程任务前的操作
        @Override
        protected void onPreExecute() {
        }

        //接收输入参数、执行任务中的耗时操作、返回 线程任务执行的结果
        @Override
        protected String doInBackground(String... strings) {
            //代表子线程
            System.out.println("doInBackground");
            //利用子线程请求数据
            return HTTP.requestHttpGet(strings[0]);
        }

        //接收线程任务执行结果、将执行结果显示到UI组件
        @Override
        protected void onPostExecute(String s) {
            System.out.println("onPostExecute");
            getData(s);
            System.out.println(s);
            chatroomListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    if (user_id == -1){
                        MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog);
                        dialog.show();
                        return;
                    }

                    Intent intent = new Intent(getActivity(), ChatActivity.class);
                    intent.putExtra("chatroomID",idList.get(position));//使点击的item对应的chatroomID可在activity间传递
                    intent.putExtra("chatroomName",nameList.get(position));//使点击的item对应的chatroomName可在activity间传递
                    intent.putExtra("user_id", user_id);
                    intent.putExtra("user_name", user_name);
                    intent.putExtra("photot_id", photo_id);
                    System.out.println(idList.get(position));//debug
                    startActivity(intent);

                }
            });
        }

    }

    public void getData(String str) {

        try {
            JSONObject resJSON = new JSONObject(str);

            String status = resJSON.getString("status");

            JSONArray array = resJSON.getJSONArray("data");
            for (int i = 0; i < array.length(); i++) {
                int id = array.getJSONObject(i).getInt("id");
                String name = array.getJSONObject(i).getString("name");

                Chatroom chatroom = new Chatroom(id, name);
                idList.add(id);//存放chatroomID
                nameList.add(name);//存放chatroomName
                chatroomList.add(chatroom);

                System.out.println("add one chatroom");//debug
                System.out.println(id);//debug
                System.out.println(name);//debug
            }

            System.out.println("adapter");//debug

            adapter = new ChatroomAdapter(getActivity(), R.layout.chatroom_item, chatroomList);
            chatroomListView = (ListView) getView().findViewById(R.id.chat_list_view);
            chatroomListView.setAdapter(adapter);

            System.out.println("finish");//debug

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}