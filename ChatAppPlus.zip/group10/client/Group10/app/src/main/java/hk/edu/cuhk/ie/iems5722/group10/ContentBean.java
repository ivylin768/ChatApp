package hk.edu.cuhk.ie.iems5722.group10;

public class ContentBean {
    private int result;
    private String content;

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content.replace("{br}","\n");
    }
}
