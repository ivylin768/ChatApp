package hk.edu.cuhk.ie.iems5722.group10;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Signup extends AppCompatActivity {
    EditText emai1;
    EditText password;
    EditText name;
    EditText authcode;
    Button btn1;
    Button btn2;
    RequestQueue queue;
    String photoid = "1";

    String sendSignupURL = new APIReader().signup;
    String sendAuthCodeURL = new APIReader().authcode;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_account, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        queue = VolleySingleton.getInstance(this.getApplicationContext()).
                getRequestQueue();

        emai1 = (EditText) findViewById(R.id.sp_account_input);
        password = (EditText) findViewById(R.id.sp_password_input);
        name = (EditText) findViewById(R.id.sp_new_name);
        authcode = (EditText) findViewById(R.id.sp_authcode);


        btn1 = (Button)findViewById(R.id.btn_signupsp);
        btn1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (checkInput(emai1.getText().toString(), password.getText().toString(), name.getText().toString())){
                    StringRequest sr = sendSignup();
                    queue.add(sr);
                }
                else{
                    String title = "SignUp";
                    String content = "Wrong input, try again.";
                    MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                    dialog.show();
                }
            }
        });

        btn2 = (Button)findViewById(R.id.btn_getauth);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (checkEmail(emai1.getText().toString())){
                    StringRequest sr = sendEmail();
                    queue.add(sr);
                }
                else{
                    String title = "SignUp";
                    String content = "Wrong email format, try again.";
                    MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                    dialog.show();
                }
            }
        });
    }

    private boolean checkInput(String emailAddress, String passWord, String nameInput){
        String regex_email = "\\w+@\\w+(\\.\\w{2,3})*\\.\\w{2,3}";
        String regex_password = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$";
        String regex_name = "^\\w+$";
        return (emailAddress.matches(regex_email) && passWord.matches(regex_password) &&
                nameInput.matches(regex_name) && nameInput.length()<=10 && nameInput.length()>=3);
    }

    private boolean checkEmail(String emailAddress){
        String regex_email = "\\w+@\\w+(\\.\\w{2,3})*\\.\\w{2,3}";
        return emailAddress.matches(regex_email);
    }


    private StringRequest sendSignup(){
        final String TAG = "sendSignup";

        return new StringRequest(Request.Method.POST, sendSignupURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                final int user_id = json.getInt("message");
                                String title = "Signup";
                                String content = "Successfull signup.";
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content,
                                        new MyDialog.OncloseListener() {
                                            @Override
                                            public void onClick(boolean confirm) {
                                                Intent intent = new Intent(Signup.this, MainActivity.class);
                                                intent.putExtra("user_id", user_id);
                                                intent.putExtra("user_name", name.getText().toString());
                                                intent.putExtra("photot_id", photoid);
                                                startActivity(intent);
                                            }
                                        });
                                dialog.show();
                            }
                            else if (json.getString("message").equals("exists")){
                                String title = "Signup";
                                String content = "Email address already exisits. Try login.";
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                            else if (json.getString("message").equals("wrong")){
                                String title = "Signup";
                                String content = "Wrong auth code. Try again.";
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                            else{
                                String title = "Signup";
                                String content = json.getString("message");
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email",emai1.getText().toString());
                params.put("password",password.getText().toString());
                params.put("name",name.getText().toString());
                params.put("photoid", photoid);
                params.put("authcode", authcode.getText().toString());
                return params;
            }
        };
    }


    private StringRequest sendEmail(){
        final String TAG = "sendEmail";

        return new StringRequest(Request.Method.POST, sendAuthCodeURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            if (status.equals("OK")){
                                String title = "Signup";
                                String content = "Check email for auth code. Expired in 10 minutes.";
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                                dialog.show();

                            }
                            else{
                                String title = "Signup";
                                String content = json.getString("message");
                                MyDialog dialog = new MyDialog(Signup.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("email",emai1.getText().toString());
                return params;
            }
        };
    }
}