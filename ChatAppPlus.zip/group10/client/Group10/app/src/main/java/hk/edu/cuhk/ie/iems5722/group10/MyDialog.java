package hk.edu.cuhk.ie.iems5722.group10;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MyDialog extends Dialog implements View.OnClickListener {

    private TextView mTitle, mContent;
    private TextView mConfirm;

    private Context mContext;
    private String content;
    private String title;
    private OncloseListener listener;

    public MyDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
        this.mContext = context;
    }

    public MyDialog(@NonNull Context context, int themeResId, OncloseListener listener) {
        super(context, themeResId);
        this.mContext = context;
        this.listener = listener;
    }

    public MyDialog(@NonNull Context context, int themeResId,  String title, String content) {
        super(context, themeResId);
        this.mContext = context;
        this.title = title;
        this.content = content;
    }


    public MyDialog(@NonNull Context context, int themeResId,  String title, String content, OncloseListener listener) {
        super(context, themeResId);
        this.mContext = context;
        this.title = title;
        this.content = content;
        this.listener = listener;
    }

    /**
     * 设置弹框标题
     * @param title 标题内容
     * @return
     */
    public MyDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    /**
     * 设置弹框的提示内容
     * @param content 弹框的提示内容
     * @return
     */
    public MyDialog setContent(String content) {
        this.content = content;
        return this;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alert_dialog);
        setCanceledOnTouchOutside(false);
        mTitle = findViewById(R.id.dialog_title);
        mContent = findViewById(R.id.dialog_content);
        mConfirm = findViewById(R.id.confirm);

        if (title!=null){
            mTitle.setText(title);
        }
        if (content!=null){
            mContent.setText(content);
        }

        mConfirm.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.confirm:
                if (listener != null) {
                    listener.onClick(true);
                }
                this.dismiss();
                break;
        }
    }

    public interface OncloseListener {
        void onClick(boolean confirm);
    }
}
