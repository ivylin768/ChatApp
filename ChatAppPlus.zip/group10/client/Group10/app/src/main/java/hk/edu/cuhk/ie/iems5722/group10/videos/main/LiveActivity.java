package hk.edu.cuhk.ie.iems5722.group10.videos.main;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import hk.edu.cuhk.ie.iems5722.group10.R;
import io.vov.vitamio.Vitamio;
import io.vov.vitamio.widget.VideoView;

public class LiveActivity extends AppCompatActivity {

    private static final String TAG = LiveActivity.class.getSimpleName();
    private static final int RETRY_TIMES = 5;
    private static final int AUTO_HIDE_TIME = 5000;

    private String mUrl;
    private String mTitle;
    private VideoView mVideoView;
    private int mCount = 0;
    private RelativeLayout mLoadingLayout;
    private RelativeLayout mrootView;
    private LinearLayout mBottomTool;
    private Handler mHandler = new Handler(Looper.getMainLooper());
    private ImageButton mPlayBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live);
        mUrl = getIntent().getStringExtra("url");
        mTitle = getIntent().getStringExtra("title");
        Log.d(TAG, ">> on Create mTitle=" + mTitle + ", mUrl=" + mUrl);

        initView();

        initPlayer();
    }

    private void initView() {
        //定义标题栏
        setTitle(mTitle);

        mLoadingLayout = (RelativeLayout) findViewById(R.id.live_loading_layout);
        Vitamio.isInitialized(LiveActivity.this);

        mrootView = (RelativeLayout) findViewById(R.id.activity_live);
        mBottomTool = (LinearLayout) findViewById(R.id.tv_play_tools);

        mrootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mBottomTool.getVisibility() == View.VISIBLE) {
                    mBottomTool.setVisibility(View.GONE);
                    return;
                }
                if (mVideoView.isPlaying()) { //根据播放状态切换图标显示
                    mPlayBtn.setImageResource(R.drawable.tv_pause);
                } else {
                    mPlayBtn.setImageResource(R.drawable.tv_play);
                }
                mBottomTool.setVisibility(View.VISIBLE);
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mBottomTool.setVisibility(View.GONE);
                    }
                }, AUTO_HIDE_TIME);
            }
        });
    }

    private void initPlayer() {
        Vitamio.isInitialized(getApplicationContext());
        mVideoView = (VideoView) findViewById(R.id.surface_view);
        mPlayBtn = (ImageButton) findViewById(R.id.tv_play);
        mVideoView.setVideoURI(Uri.parse(mUrl));
        mVideoView.setOnPreparedListener(new io.vov.vitamio.MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(io.vov.vitamio.MediaPlayer mp) {
                mVideoView.start();
            }
        });

        mPlayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mVideoView.isPlaying()) {//暂停
                    mVideoView.stopPlayback();
                    mPlayBtn.setImageResource(R.drawable.tv_play);
                } else {
                    mVideoView.setVideoURI(Uri.parse(mUrl));
                    mVideoView.setOnPreparedListener(new io.vov.vitamio.MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(io.vov.vitamio.MediaPlayer mp) {
                            mVideoView.start();
                        }
                    });
                    mPlayBtn.setImageResource(R.drawable.tv_pause);
                }
            }
        });

        mVideoView.setOnErrorListener(new io.vov.vitamio.MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(io.vov.vitamio.MediaPlayer mp, int what, int extra) {
                if (mCount > RETRY_TIMES) {
                    new AlertDialog.Builder(LiveActivity.this)
                            .setMessage(R.string.error_msg)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    LiveActivity.this.finish();
                                }
                            }).setCancelable(false).show();
                } else {
                    mVideoView.stopPlayback();
                    mVideoView.setVideoURI(Uri.parse(mUrl));
                }
                mCount ++;
                return false;
            }
        });
        mVideoView.setOnInfoListener(new io.vov.vitamio.MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(io.vov.vitamio.MediaPlayer mp, int what, int extra) {
                switch (what) {
                    case MediaPlayer.MEDIA_INFO_BUFFERING_START://视频加载中
                        mLoadingLayout.setVisibility(View.VISIBLE);
                        break;
                    case MediaPlayer.MEDIA_INFO_BUFFERING_END: //视频加载完毕
                    case MediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING://音频先于视频出现
                        mLoadingLayout.setVisibility(View.GONE);
                        break;
                }
                return false;
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        mCount = 0;
        if (mVideoView != null) {
            mVideoView.stopPlayback();
        }
    }

}
