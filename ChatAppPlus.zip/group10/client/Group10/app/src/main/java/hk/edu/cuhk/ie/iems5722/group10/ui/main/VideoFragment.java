package hk.edu.cuhk.ie.iems5722.group10.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.MediaController;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.android.volley.toolbox.StringRequest;

import hk.edu.cuhk.ie.iems5722.group10.APIReader;
import hk.edu.cuhk.ie.iems5722.group10.MyDialog;
import hk.edu.cuhk.ie.iems5722.group10.R;
import hk.edu.cuhk.ie.iems5722.group10.VolleySingleton;
import hk.edu.cuhk.ie.iems5722.group10.games.main.GameDrawActivity;
import hk.edu.cuhk.ie.iems5722.group10.games.main.GameTTTlActivity;
import hk.edu.cuhk.ie.iems5722.group10.ui.main.GameFragment;
import hk.edu.cuhk.ie.iems5722.group10.videos.main.TvliveActivity;
import hk.edu.cuhk.ie.iems5722.group10.videos.main.VideoplayerActivity;

/**
 * A placeholder fragment containing a simple view.
 */
public class VideoFragment extends Fragment {

    int user_id = -1;
    String user_name;
    String photo_id;


    public static VideoFragment newInstance(int usr_id, String usr_name, String phto_id) {
        VideoFragment fragment = new VideoFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("user_id", usr_id);
        bundle.putString("user_name", usr_name);
        bundle.putString("photo_id", phto_id);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_mvideos, container, false);
        Bundle bundle = getArguments();
        user_id = bundle.getInt("user_id");
        user_name = bundle.getString("user_name");
        photo_id = bundle.getString("photo_id");
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        ImageButton btn1 = getView().findViewById(R.id.videoplayer);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//看本地/网络视频，无需登录
//                if (user_id == -1) {
//                    MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog);
//                    dialog.show();
//                    return;
//                }

                Intent intent = new Intent(getActivity(), VideoplayerActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
            }
        });

        ImageButton btn2 = getView().findViewById(R.id.live);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { //看电视节目直播，需登录
                if (user_id == -1) {
                    MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog);
                    dialog.show();
                    return;
                }
                Intent intent = new Intent(getActivity(), TvliveActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
            }
        });

    }
}
