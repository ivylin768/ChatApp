package hk.edu.cuhk.ie.iems5722.group10;

import com.google.gson.Gson;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RobotActivity extends AppCompatActivity {

    int user_id;
    String user_name;
    String photo_id;
    String send_content = "";

    private ListView msgListView;
    private EditText inputText;
    private ImageButton sendBtn;// 发送按钮
    private MSGAdapter adapter;// 消息视图的Adapter
    private List<MSG> msgList = new ArrayList<MSG>();// 消息对象数组


    private Handler handler = new Handler() {
      @Override
      public void handleMessage(@NonNull Message msg) {
          switch (msg.what){
              case 1:{
                  String robot_name = "菲菲";
                  String format_time = (String)(new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(new Date());//set time format
                  Bundle data = msg.getData();
                  String result = data.getString("result");
                  MSG robotMsg = new MSG(result,robot_name,format_time,MSG.TYPE_RECEIVED);
                  msgList.add(robotMsg);
                  ////
                  adapter.notifyDataSetChanged();//刷新适配器,通知ListView，数据已发生改变
                  msgListView.setSelection(adapter.getCount()-1);///
              }break;
              case 2:{}break;
              default:break;
          }
      }
    };


    private void getInter(String content){
        HTTP.getResponse(RobotManager.newUrl(content), new GetConnection() {
            @Override
            public void onFinish(String response) {
                ContentBean contentBean = new ContentBean();
                Log.e("getResult",response);
                Message msg = new Message();
                Bundle data = new Bundle();
                Gson gson = new Gson();
                contentBean = gson.fromJson(response,ContentBean.class);	//用Gson将返回内容序列化为ContentBean对象。
                if(contentBean.getResult()==0){
                    data.putString("result",contentBean.getContent());
                }else{
                    data.putString("result","Sorry I don't understand");
                }
                msg.setData(data);
                msg.what = 1;
                handler.sendMessage(msg);
            }

            @Override
            public void onError(Exception e) {
                e.printStackTrace();
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        user_name = getIntent().getExtras().getString("user_name");
        user_id = getIntent().getExtras().getInt("user_id");
        photo_id = getIntent().getExtras().getString("photot_id");

        setTitle("Chatbot");//set activity label name as room name

        initMsgs();//初始化消息

        adapter = new MSGAdapter(RobotActivity.this, R.layout.msg_item, msgList);
        inputText = (EditText)findViewById(R.id.input_text);
        sendBtn = (ImageButton)findViewById(R.id.send_btn);
        msgListView = (ListView)findViewById(R.id.msg_list_view);
        msgListView.setAdapter(adapter);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                send_content = inputText.getText().toString();//get sent content
                String format_time = (String)(new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(new Date());//set time format, new Date()为获取当前系统时间
                if(!"".equals(send_content)) {

                    MSG msg = new MSG(send_content,user_name,format_time,MSG.TYPE_POST);///
                    msgList.add(msg);
                    getInter(send_content);
                    Log.e("url", RobotManager.newUrl(send_content));
                    adapter.notifyDataSetChanged();//刷新适配器,通知ListView，数据已发生改变
                    msgListView.setSelection(adapter.getCount()-1);///

                    inputText.setText("");// 清空编辑框数据
                }
            }
        });
    }

    private void initMsgs() {
        String robot_name = "菲菲";
        String format_time = (String)(new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(new Date());//set time format
        MSG msg1 = new MSG("Hello, I'm Feifei. Come & chat with me in Chinese!* ( ´͈ ᵕ `͈ )",robot_name,format_time, MSG.TYPE_RECEIVED);
        msgList.add(msg1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(RobotActivity.this, MainActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }
}
