package hk.edu.cuhk.ie.iems5722.group10;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.tabs.TabLayout;

import hk.edu.cuhk.ie.iems5722.group10.ui.main.SectionsPagerAdapter;

import static hk.edu.cuhk.ie.iems5722.group10.R.id.view_pager;

public class MainActivity extends AppCompatActivity {

    int user_id=-1;
    public static String user_name = "default1";
    String photo_id;


    //主线程
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 绑定UI组件
        setContentView(R.layout.activity_main);
        try{
            user_name = getIntent().getExtras().getString("user_name");
            user_id = getIntent().getExtras().getInt("user_id");
            photo_id = getIntent().getExtras().getString("photot_id");
        } catch (Exception e){
            Log.d("onCreate","no info");
        }

        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager(), user_id, user_name, photo_id);
        ViewPager viewPager = findViewById(view_pager);
        viewPager.setAdapter(sectionsPagerAdapter);

        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);


        TabLayout tabs = findViewById(R.id.tabs);
        tabs.setupWithViewPager(viewPager);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        if (user_id==-1){
            getMenuInflater().inflate(R.menu.menu_main, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_main_in, menu);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.usr) {
            if (user_id==-1){
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            } else{
                String title = "Account";
                String content = String.format("Your have been already login as %s", user_name);
                MyDialog dialog = new MyDialog(MainActivity.this, R.style.mdialog, title, content);
                dialog.show();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
