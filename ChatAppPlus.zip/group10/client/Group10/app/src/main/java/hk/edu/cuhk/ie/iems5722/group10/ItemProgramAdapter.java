package hk.edu.cuhk.ie.iems5722.group10;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import hk.edu.cuhk.ie.iems5722.group10.videos.main.LiveActivity;

public class ItemProgramAdapter extends BaseAdapter {

    private Context mContext;

    //数据集
    private String[] mDataList = new String[] {
            "CCTV1","CCTV2","CCTV3","CCTV4","CCTV5","CCTV6","CCTV7","CCTV8","CCTV9","CCTV10","CCTV11","CCTV12","CCTV13","CCTV14","CCTV15"
    };

    private String[] mUrlList = new String[] {
            "http://ivi.bupt.edu.cn/hls/cctv1hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv2hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv3hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv4hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv5hd.m3u8",//
            "http://ivi.bupt.edu.cn/hls/cctv6hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv7hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv8hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv9hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv10hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv11hd.m3u8",//
            "http://ivi.bupt.edu.cn/hls/cctv12hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv13hd.m3u8",//
            "http://ivi.bupt.edu.cn/hls/cctv14hd.m3u8",
            "http://ivi.bupt.edu.cn/hls/cctv15hd.m3u8"//
    };

    @Override
    public int getCount() {
        return mDataList.length;
    }

    public ItemProgramAdapter(Context context) {
        mContext = context;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        tvViewHolder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from(mContext).inflate(R.layout.tv_item,null);
            holder = new tvViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (tvViewHolder) convertView.getTag();
        }
        holder.textView.setText(mDataList[position]);
        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, LiveActivity.class);
                intent.putExtra("url",mUrlList[position]);
                intent.putExtra("title",mDataList[position]);
                mContext.startActivity(intent);
            }
        });
        return convertView;
    }

    public class tvViewHolder {
        TextView textView;
        public tvViewHolder(View view) {
            textView = (TextView) view.findViewById(R.id.tv_program_item_title);
        }
    }
}
