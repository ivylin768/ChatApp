package hk.edu.cuhk.ie.iems5722.group10.games.main;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.GnssMeasurement;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import hk.edu.cuhk.ie.iems5722.group10.APIReader;
import hk.edu.cuhk.ie.iems5722.group10.ChatActivity;
import hk.edu.cuhk.ie.iems5722.group10.Login;
import hk.edu.cuhk.ie.iems5722.group10.MainActivity;
import hk.edu.cuhk.ie.iems5722.group10.MyDialog;
import hk.edu.cuhk.ie.iems5722.group10.VolleySingleton;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import hk.edu.cuhk.ie.iems5722.group10.R;

public class GameTTTlActivity extends AppCompatActivity {
    private Socket socket;
    RequestQueue queue;

    int r = 3;
    int c = 2;
    int user_id=-1;
    String user_name;
    String photo_id;

    int table_id = -1;
    int pos_id = -1;
    int set_table_id = -1;
    int set_pos_id = -1;
    int set_start_game = -1;
    int set_end_game = -1;
    int set_chess_x = -1;
    int set_chess_y = -1;
    int set_chess_type = -1;

    TextView txInfo;
    TextView txTurnInfo;

    Button [][] btnArrSit = new Button[r][c];
    ImageButton [][] btnArrLeave = new ImageButton[r][c];
    Button [] btnArrStart = new Button[r];
    ImageButton [][][] btnArrChessboard = new ImageButton[r][3][3];
    LinearLayout [] lvs = new LinearLayout[3];


    int game_status = 0;
    int label = 0;
    Drawable originBtnArrSitDrawable;
    Drawable originBtnArrStartDrawable;
    Drawable originLinearLayoutDrawable;

    // Tileid
    static private int[] cboards = {R.id.large1, R.id.large2, R.id.large3};
    static private int[][] mSmallIds= {
            {R.id.small1, R.id.small2, R.id.small3},
            {R.id.small4, R.id.small5, R.id.small6},
            {R.id.small7, R.id.small8, R.id.small9,}};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.game_ttt);
        try{
            user_name = getIntent().getExtras().getString("user_name");
            user_id = getIntent().getExtras().getInt("user_id");
            photo_id = getIntent().getExtras().getString("photot_id");
        } catch (Exception e){
            Log.d("onCreate","no info");
        }

        initSocketIO();
        initButtomArr();

        queue = VolleySingleton.getInstance(this.getApplicationContext()).
                getRequestQueue();
        StringRequest initalTableRequest = initalTable();
        queue.add(initalTableRequest);

        setSitButtom();
        setLeaveButton();
        setStartButton();
    }

    private void initSocketIO(){
        String uri = new APIReader().socketio_ttt;
        try{
            socket = IO.socket(uri);
            socket.on(Socket.EVENT_CONNECT, onConnectSuccess);
            socket.on(Socket.EVENT_CONNECT_ERROR, onConnectError);
            socket.on(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
            socket.on("update_table", onTableUpdate);
            socket.connect();
        } catch (URISyntaxException e){
            e.printStackTrace();
        }

        if (socket != null){
            try {
                JSONObject json = new JSONObject();
                json.put("user_id", user_id);
                socket.emit("connect_n", json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private Emitter.Listener onConnectSuccess = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d("onConnectSuccess" ,"WebSocket successfully connected...");
        }
    };

    private Emitter.Listener onTableUpdate = new Emitter.Listener() {
        @Override
        public void call(final Object... args) {
            Log.d("onTableUpdate" ,"update table status...");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    StringRequest initalTableRequest = initalTable();
                    queue.add(initalTableRequest);
                }
            });
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            if (args[0] instanceof Throwable) {
                ((Throwable) args[0]).printStackTrace();
            }
            System.out.println("error message" + args[0]);
        }
    };

    @Override
    protected void onDestroy(){
        if (socket != null){
            try {
                JSONObject json = new JSONObject();
                json.put("user_id", user_id);
                json.put("user_name", user_name);
                json.put("table_id", table_id);
                json.put("pos_id", pos_id);
                json.put("game_status", game_status);
                socket.emit("disconnect_n", json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            socket.disconnect();
            socket.off();
        }
        super.onDestroy();
    }

    @Override
    protected void onStop(){
        if (socket != null){
            try {
                JSONObject json = new JSONObject();
                json.put("user_id", user_id);
                json.put("user_name", user_name);
                json.put("table_id", table_id);
                json.put("pos_id", pos_id);
                json.put("game_status", game_status);
                socket.emit("disconnect_n", json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            socket.disconnect();
            socket.off();
        }
        super.onStop();
    }


    private void initButtomArr(){
        // sit buttom
        btnArrSit[0][0] = findViewById(R.id.t1Left);
        btnArrSit[0][1] = findViewById(R.id.t1Right);
        btnArrSit[1][0] = findViewById(R.id.t2Left);
        btnArrSit[1][1] = findViewById(R.id.t2Right);
        btnArrSit[2][0] = findViewById(R.id.t3Left);
        btnArrSit[2][1] = findViewById(R.id.t3Right);

        originBtnArrSitDrawable = btnArrSit[0][0].getBackground();

        // leave buttom
        btnArrLeave[0][0] = findViewById(R.id.t1LeftLeave);
        btnArrLeave[0][1] = findViewById(R.id.t1RightLeave);
        btnArrLeave[1][0] = findViewById(R.id.t2LeftLeave);
        btnArrLeave[1][1] = findViewById(R.id.t2RightLeave);
        btnArrLeave[2][0] = findViewById(R.id.t3LeftLeave);
        btnArrLeave[2][1] = findViewById(R.id.t3RightLeave);

        // start buttom
        btnArrStart[0] = findViewById(R.id.t1start);
        btnArrStart[1] = findViewById(R.id.t2start);
        btnArrStart[2] = findViewById(R.id.t3start);
        originBtnArrStartDrawable = btnArrStart[0].getBackground();

        // chess board
        for (int i=0; i<r;i++){
            GridLayout glTmp = findViewById(cboards[i]);
            for (int j=0; j<3; j++){
                for (int k=0; k<3;k++){
                    btnArrChessboard[i][j][k] = glTmp.findViewById(mSmallIds[j][k]);
                }
            }
        }

        lvs[0] = (LinearLayout) findViewById(R.id.field1);
        lvs[1] = (LinearLayout)findViewById(R.id.field2);
        lvs[2] = (LinearLayout)findViewById(R.id.field3);

        originLinearLayoutDrawable = lvs[0].getBackground();

        txTurnInfo = findViewById(R.id.turn);
    }

    private void setSitButtom(){
        for(int x=0;x<r;x++){
            for (int y=0; y<c; y++){
                final int curr_x = x;
                final int curr_y = y;
                btnArrSit[x][y].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (table_id==-1&&pos_id==-1){
                            set_table_id = curr_x;
                            set_pos_id = curr_y;
                            StringRequest sr = sendSitTable();
                            queue.add(sr);
                        } else if (table_id!=-1){
                            String title = "Tic Tac Toe";
                            String content = "Already have a sit.";
                            MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                            dialog.show();
                        }
                    }
                });
            }
        }
    }

    private void setLeaveButton(){
        for(int x=0;x<r;x++) {
            for (int y = 0; y < c; y++) {
                final int curr_x = x;
                final int curr_y = y;
                btnArrLeave[x][y].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (table_id == curr_x && pos_id == curr_y) {
                            StringRequest sr = sendLeaveTable();
                            queue.add(sr);
                        }
                    }
                });
            }
        }
    }

    private void setStartButton(){
        for(int x=0;x<r;x++){
            final int curr_x = x;
            btnArrStart[x].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (table_id == curr_x){
                        if (game_status==0){
                            set_start_game = curr_x;
                            StringRequest sr = sendStartGame();
                            queue.add(sr);
                        }
                        else{
                            set_end_game = curr_x;
                            StringRequest sr = sendEndGame();
                            queue.add(sr);
                        }
                    }
                }
            });
        }
    }
    private void setChessBoardButton(){
        // set onclick listener
        for (int x=0; x<3; x++){
            for (int y=0; y<3; y++){
                final int curr_x = x;
                final int curr_y = y;
                btnArrChessboard[table_id][x][y].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (game_status-pos_id == 1 && btnArrChessboard[table_id][curr_x][curr_y].getDrawable().getLevel()==0){  //game_status == 1: left position = 0
                            set_chess_x = curr_x;
                            set_chess_y = curr_y;
                            set_end_game = curr_x;
                            set_chess_type = pos_id + 1;
                            StringRequest sr = sendMoveChess();
                            queue.add(sr);
                        }
                    }
                });
            }
        }
    }



    private StringRequest initalTable(){
        String MessageURL = String.format(new APIReader().get_table);
        return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    JSONObject data = json.getJSONObject("data");

                    // sit status
                    JSONArray sitArray = data.getJSONArray("sit_status");
                    for (int i=0; i<r;i++){
                        for (int j=0; j<c;j++){
                            String tmp = sitArray.getJSONArray(i).getString(j);
                            if (tmp.equals("-1")){
                                Button bt = btnArrSit[i][j];
                                bt.setText(R.string.free);
                            }else {
                                Button bt = btnArrSit[i][j];
                                bt.setText(tmp);
                                if (user_name.equals(tmp)){
                                    btnArrSit[i][j].setBackgroundColor(getResources().getColor(R.color.blue_color));
                                }
                            }
                        }
                    }
                    // game status
                    JSONArray playStatus = data.getJSONArray("play_status");
                    for (int i=0; i<r; i++){
                        int tmp = Integer.parseInt(playStatus.getString(i));
                        if (tmp==0){  // not in game, original format
                            if (i == table_id){
                                game_status = 0;
                            }
                            btnArrStart[i].setText(R.string.start);
                            btnArrStart[i].setBackground(originBtnArrStartDrawable);
                        }else if (i == table_id){  // in game and is my game
                            btnArrStart[i].setText(R.string.play_quit);
                            btnArrStart[i].setBackgroundColor(getResources().getColor(R.color.red_color));
                            game_status = tmp;
                            setChessBoardButton();
                        }else{  //in game but not my game
                            btnArrStart[i].setText(R.string.play);
                            btnArrStart[i].setBackgroundColor(getResources().getColor(R.color.red_color));
                        }
                    }

                    // chessboard status
                    JSONArray chessBoard = data.getJSONArray("chessboard");
                    for (int i=0; i<r; i++){  //3个chessboard
                        for (int j=0; j<3; j++){
                            for (int k=0; k<3;k++){
                                int t = Integer.parseInt(chessBoard.getJSONArray(i).getJSONArray(j).getString(k));
                                btnArrChessboard[i][j][k].setImageLevel(t);
                            }
                        }
                    }

                    // table status
                    if (game_status!=0){
                        JSONArray table_status = data.getJSONArray("table_status");
                        int t = Integer.parseInt(table_status.getString(table_id));

                        if (t != -1){
                            String title = "Tic Tac Toe";
                            String content;
                            if (t==0){
                                content = "Even.";
                            } else if (t-pos_id == 1){
                                content = "You Win.";
                            } else{
                                content = "You lose.";
                            }
                            MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content, new MyDialog.OncloseListener() {
                                @Override
                                public void onClick(boolean confirm) {
                                    StringRequest sr = sendEndGame();
                                    queue.add(sr);
                                }
                            });
                            dialog.show();
                            label = 1;
                        }
                    }

                    txInfo = findViewById(R.id.textInfo);
                    if (table_id==-1){
                        String info = ", you can select a table.";
                        txInfo.setText("Hi,"+user_name+info);
                        for (int i=0; i<r;i++){
                            lvs[i].setBackground(originLinearLayoutDrawable);
                        }
                    }else{
                        String info = String.format(", you are in table %d", table_id+1);
                        txInfo.setText("Hi,"+user_name+info);
                        lvs[table_id].setBackgroundColor(getResources().getColor(R.color.field_color));
                    }

                    if (game_status==0){
                        txTurnInfo.setVisibility(View.GONE);
                    }else if (game_status-pos_id == 1){  //game_status == 1: left position = 0
                        txTurnInfo.setVisibility(View.VISIBLE);
                        txTurnInfo.setText("Your Turn");
                    } else{
                        txTurnInfo.setVisibility(View.VISIBLE);
                        txTurnInfo.setText("Wait");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("initalTable","error in inital table");
                error.printStackTrace();
            }
        });
    }

    private StringRequest sendSitTable(){
        final String TAG = "sendSitTable";

        return new StringRequest(Request.Method.POST, new APIReader().sit_table,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");  // todo: if status == 'error'
                            if (status.equals("OK")){
                                table_id = set_table_id;
                                pos_id = set_pos_id;
                            } else{
                                String title = "Tic Tac Toe";
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table_id",Integer.toString(set_table_id));
                params.put("pos_id",Integer.toString(set_pos_id));
                params.put("user_id",Integer.toString(user_id));
                params.put("user_name",user_name);
                return params;
            }
        };
    }


    private StringRequest sendLeaveTable(){
        final String TAG = "sendLeaveTable";

        return new StringRequest(Request.Method.POST, new APIReader().leave_table,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");  // todo: if status == 'error'
                            if (status.equals("OK")){
                                System.out.println("leave ok");
                                btnArrSit[table_id][pos_id].setBackground(originBtnArrSitDrawable);
                                table_id = -1;
                                pos_id = -1;
                            } else{
                                String title = "Tic Tac Toe";
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table_id",Integer.toString(table_id));
                params.put("pos_id",Integer.toString(pos_id));
                params.put("user_id",Integer.toString(user_id));
                params.put("user_name",user_name);
                return params;
            }
        };
    }


    private StringRequest sendStartGame(){
        final String TAG = "sendStartGame";

        return new StringRequest(Request.Method.POST, new APIReader().start_game,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");  // todo: if status == 'error'
                            if (status.equals("OK")){
                                String title = "Tic Tac Toe";
                                String content = "Game start.";
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                                game_status = (pos_id == 0)? 1:2;
                                label = 0;
                                btnArrStart[table_id].setBackgroundResource(R.color.red_color);
                                btnArrStart[table_id].setText(R.string.play_quit);
                                setChessBoardButton();
                            } else{
                                String title = "Tic Tac Toe";
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table_id",Integer.toString(set_start_game));
                return params;
            }
        };
    }

    private StringRequest sendEndGame(){
        final String TAG = "sendEndGame";

        return new StringRequest(Request.Method.POST, new APIReader().end_game,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");
                            String title = "Tic Tac Toe";
                            String content;
                            if (status.equals("OK")){
                                content = "Quit Game.";
                                game_status = 0;
                                btnArrStart[table_id].setBackground(originBtnArrStartDrawable);
                                btnArrStart[table_id].setText(R.string.start);
                            } else{
                                content = json.getString("data");
                            }
                            if (label == 0){
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table_id",Integer.toString(set_end_game));
                return params;
            }
        };
    }


    private StringRequest sendMoveChess(){
        final String TAG = "sendMoveChess";

        return new StringRequest(Request.Method.POST, new APIReader().move_chess,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        JSONObject json = null;
                        try {
                            json = new JSONObject(response);
                            String status = json.getString("status");  // todo: if status == 'error'
                            if (!status.equals("OK")){
                                String title = "Tic Tac Toe";
                                String content = json.getString("data");
                                MyDialog dialog = new MyDialog(GameTTTlActivity.this, R.style.mdialog, title, content);
                                dialog.show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, error.toString());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("table_id",Integer.toString(table_id));
                params.put("chess_x",Integer.toString(set_chess_x));
                params.put("chess_y",Integer.toString(set_chess_y));
                params.put("chess_type",Integer.toString(set_chess_type));
                return params;
            }
        };
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case android.R.id.home:
                Intent intent = new Intent(GameTTTlActivity.this, MainActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }

}

