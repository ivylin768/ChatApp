package hk.edu.cuhk.ie.iems5722.group10.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import hk.edu.cuhk.ie.iems5722.group10.APIReader;
import hk.edu.cuhk.ie.iems5722.group10.MyDialog;
import hk.edu.cuhk.ie.iems5722.group10.R;
import hk.edu.cuhk.ie.iems5722.group10.VolleySingleton;
import hk.edu.cuhk.ie.iems5722.group10.games.main.GameDrawActivity;
import hk.edu.cuhk.ie.iems5722.group10.games.main.GameTTTlActivity;

/**
 * A placeholder fragment containing a simple view.
 */
public class GameFragment extends Fragment {

    int user_id=-1;
    String user_name;
    String photo_id;
    RequestQueue queue;

    public static GameFragment newInstance(int usr_id, String usr_name, String phto_id) {
        GameFragment fragment = new GameFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("user_id", usr_id);
        bundle.putString("user_name", usr_name);
        bundle.putString("photo_id", phto_id);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_mgames, container, false);
        Bundle bundle = getArguments();
        user_id = bundle.getInt("user_id");
        user_name = bundle.getString("user_name");
        photo_id = bundle.getString("photo_id");
        return root;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        queue = VolleySingleton.getInstance(getActivity().getApplicationContext()).
                getRequestQueue();

        ImageButton btn1 = getView().findViewById(R.id.game1);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (user_id == -1){
                    MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog);
                    dialog.show();
                    return;
                }

                StringRequest initPositionRequest = getGameStatus();
                queue.add(initPositionRequest);
            }
        });

        ImageButton btn2 = getView().findViewById(R.id.game2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (user_id == -1){
                    MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog);
                    dialog.show();
                    return;
                }
                Intent intent = new Intent(getActivity(), GameTTTlActivity.class);
                intent.putExtra("user_id", user_id);
                intent.putExtra("user_name", user_name);
                intent.putExtra("photot_id", photo_id);
                startActivity(intent);
            }
        });


    }

    private StringRequest getGameStatus(){
        final String TAG = "getGameStatus";
        String MessageURL = String.format(new APIReader().draw_getStatus);
        return new StringRequest(Request.Method.GET, MessageURL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject json = new JSONObject(response);
                    JSONObject data = json.getJSONObject("data");

                    // sit status
                    int status= data.getInt("game_status");
                    if (status==0){
                        Intent intent = new Intent(getActivity(), GameDrawActivity.class);
                        intent.putExtra("user_id", user_id);
                        intent.putExtra("user_name", user_name);
                        intent.putExtra("photot_id", photo_id);
                        startActivity(intent);
                    }else{
                        String title = "DRAW SOMETHING";
                        String content = "In game. Wait...";
                        MyDialog dialog = new MyDialog(getActivity(), R.style.mdialog, title, content);
                        dialog.show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG,"error in initPosition");
                error.printStackTrace();
            }
        });
    }
}