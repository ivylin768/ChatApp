from flask import Flask, jsonify, request
import mysql.connector
import math

app = Flask(__name__)#app name

class MyDatabase:
    conn = None
    cursor = None

    def __init__(self):
        self.connect()
        return

    def connect(self):
        self.conn = mysql.connector.connect(
        host = "localhost",##
        port = 3306,#default,can be ommitted
        user = "dbivy",
        password = "245425364",
        database = "iems5722",
        )

        # create a cursor that return rows as dictionaries
        self.cursor = self.conn.cursor(dictionary = True)
        return


@app.route("/api/a3/get_chatrooms")
def get_chatrooms():
    #connect to the database
    mydb1 = MyDatabase()
    #construct a query
    query1 = "SELECT * FROM chatrooms"
    #execute the query
    mydb1.cursor.execute(query1)
    #retrieve the data
    chatrooms = mydb1.cursor.fetchall()
    #format & return the data
    return jsonify(data=chatrooms,status="OK")


@app.route("/api/a3/get_messages")
def get_messages():
    #connect to the database
    #print('mydb2')
    mydb2 = MyDatabase()
    chatroom_id = int(request.args.get("chatroom_id"))
    page = int(request.args.get("page"))
    #construct & execute a query to get total number of messages in this chatroom
    query2_1 = "SELECT COUNT(message) AS total_messages FROM messages WHERE chatroom_id = %s"
    params2_1 = (chatroom_id,)
    mydb2.cursor.execute(query2_1, params2_1)
    total_messages = (mydb2.cursor.fetchone())["total_messages"]
    total_pages = int(math.ceil(float(total_messages) / 5))
    #construct & execute a query to get target messages
    i = (page-1) * 5  # index
    n = 5  # number of messages one time
    #print(total_pages,i,n)##debug
    query2_2 = "SELECT message,name,message_time,user_id FROM messages WHERE chatroom_id = %s ORDER BY id DESC LIMIT %s,%s"
    params2_2 = (chatroom_id,i,n)
    mydb2.cursor.execute(query2_2,params2_2)
    #retrieve the data
    messages = mydb2.cursor.fetchall()
    #print(messages)
    # check if the client side has supplied the correct parameters, if any parameter is missing, return the following error response instead
    if messages is None:
        return jsonify(message="<error message>",status="ERROR")
    # correct supplement
    else:
        #format & return the data
        data = {
            "current_page":page,
            "messages":messages,
            "total_pages": total_pages
        } 
        #print(data)
        return jsonify(data=data,status="OK")


@app.route("/api/a3/send_message",methods=['POST'])
def send_message():
    mydb3 = MyDatabase()
    #print('mydb3')
    chatroom_id = int(request.form.get("chatroom_id"))
    user_id = int(request.form.get("user_id"))
    name = request.form.get("name")
    message = request.form.get("message")
    #print(chatroom_id,user_id,name,message)
    query3 = "INSERT INTO messages VALUES(NULL,%s,%s,%s,%s,CURRENT_TIMESTAMP)"
    params3 = (chatroom_id,user_id,name,message)
    ###
    mydb3.cursor.execute(query3,params3)##execute INSERT
    effectRow = mydb3.cursor.rowcount #
    #print(effectRow)
    if effectRow > 0:#INSERT succeeded
        mydb3.conn.commit() #need to commit if changed the data
        return jsonify(status="OK")
    else:
        return jsonify(message="<error message>", status="ERROR")

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5000,debug=True)
