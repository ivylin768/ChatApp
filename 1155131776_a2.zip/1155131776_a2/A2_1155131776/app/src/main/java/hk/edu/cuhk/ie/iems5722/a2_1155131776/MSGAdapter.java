package hk.edu.cuhk.ie.iems5722.a2_1155131776;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


import java.util.List;


public class MSGAdapter extends ArrayAdapter<MSG> {

    private int resId;

    public MSGAdapter(Context context, int textViewResId, List<MSG> objects) {
        super(context, textViewResId, objects);
        resId = textViewResId;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        MSG msg = getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resId, null);
            viewHolder = new ViewHolder();
            viewHolder.leftLayout = (LinearLayout)view.findViewById(R.id.left_layout);
            viewHolder.rightLayout = (LinearLayout)view.findViewById(R.id.right_layout);
            viewHolder.leftUser = (TextView)view.findViewById(R.id.left_user);
            viewHolder.rightUser = (TextView)view.findViewById(R.id.right_user);
            viewHolder.leftMsg = (TextView)view.findViewById(R.id.left_content);
            viewHolder.rightMsg = (TextView)view.findViewById(R.id.right_content);
            viewHolder.leftTime = (TextView)view.findViewById(R.id.left_time);
            viewHolder.rightTime = (TextView)view.findViewById(R.id.right_time);
            view.setTag(viewHolder);
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }

        if(msg.getType() == MSG.TYPE_POST) {

            viewHolder.leftLayout.setVisibility(View.GONE);
            viewHolder.rightLayout.setVisibility(View.VISIBLE);
            viewHolder.rightUser.setText(msg.getName());
            viewHolder.rightMsg.setText(msg.getContent());
            viewHolder.rightTime.setText(msg.getDate());

        } else {

            viewHolder.leftLayout.setVisibility(View.VISIBLE);
            viewHolder.rightLayout.setVisibility(View.GONE);
            viewHolder.leftUser.setText(msg.getName());
            viewHolder.leftMsg.setText(msg.getContent());
            viewHolder.leftTime.setText(msg.getDate());

        }



        return view;

    }

    class ViewHolder {
        LinearLayout leftLayout;
        LinearLayout rightLayout;
        TextView leftUser;
        TextView rightUser;
        TextView leftMsg;
        TextView rightMsg;
        TextView leftTime;
        TextView rightTime;
    }

}
