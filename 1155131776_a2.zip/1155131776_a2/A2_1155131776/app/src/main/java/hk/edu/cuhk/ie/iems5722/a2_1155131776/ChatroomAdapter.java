package hk.edu.cuhk.ie.iems5722.a2_1155131776;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ChatroomAdapter extends ArrayAdapter<Chatroom> {

    private int resId;

    public ChatroomAdapter(Context context, int resId, List<Chatroom> objects) {
        super(context,resId,objects);
        this.resId = resId;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        Chatroom chatroom = getItem(position);
        View view;
        chatViewHolder viewHolder;
        if(convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resId,parent,false);////
            viewHolder = new chatViewHolder();
            viewHolder.chat = (TextView)view.findViewById(R.id.chat_name);
            view.setTag(viewHolder);//将viewHolder存储在view中
        } else {
            view = convertView;
            viewHolder = (chatViewHolder)view.getTag();
        }

        viewHolder.chat.setText(chatroom.getChatname()); //set the text shown on the button

        return view;
    }

    class chatViewHolder {
        TextView chat;
    }
}
