package hk.edu.cuhk.ie.iems5722.a4_1155131776;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    MainTask mTask;

    int roomId;
    String roomName = "";

    private ListView chatroomListView;
    private ChatroomAdapter adapter;
    private List<Integer> idList = new ArrayList<Integer>();//定义一个整数list存放chatroomID
    private List<String> nameList = new ArrayList<>();//定义一个list存放chatroomName

    private List<Chatroom> chatroomList = new ArrayList<>();////



    //创建AsyncTask子类
    private class MainTask extends AsyncTask<String,Integer,String> {
        //onPreExecute()执行线程任务前的操作
        @Override
        protected void onPreExecute() {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
        }

        //接收输入参数、执行任务中的耗时操作、返回 线程任务执行的结果
        @Override
        protected String doInBackground(String... strings) {
            //代表子线程
            System.out.println("doInBackground");
            //利用子线程请求数据
            return HTTP.requestHttpGet(strings[0]);
        }

        //接收线程任务执行结果、将执行结果显示到UI组件
        @Override
        protected void onPostExecute(String s) {
            System.out.println("onPostExecute");
            getData(s);
            System.out.println(s);
            //设置listview子控件item监听，原本放在onCreate里，运行后软件打不开，在Run中提示错误：Attempt to invoke virtual method xxxxxxxx on a null object reference（即为空指针），所以放在这里，getData()下面，成功运行
            chatroomListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    roomId = idList.get(position);
                    roomName = nameList.get(position);
                    Intent intent = new Intent(MainActivity.this, ChatActivity.class);
                    intent.putExtra("chatroomID",roomId);//使点击的item对应的chatroomID可在activity间传递
                    intent.putExtra("chatroomName",roomName);//使点击的item对应的chatroomName可在activity间传递
                    intent.putExtra("nameList",(Serializable) nameList);//使nameListe可在activity间传递
                    System.out.println(idList.get(position));//debug
                    startActivity(intent);

                }
            });
        }
    }

    public void getData(String str) {

        try {
            JSONObject resJSON = new JSONObject(str);

            String status = resJSON.getString("status");

            JSONArray array = resJSON.getJSONArray("data");
            for (int i = 0; i < array.length(); i++) {
                int id = array.getJSONObject(i).getInt("id");
                String name = array.getJSONObject(i).getString("name");

                Chatroom chatroom = new Chatroom(id, name);
                idList.add(id);//存放chatroomID
                nameList.add(name);//存放chatroomName
                chatroomList.add(chatroom);

                System.out.println("add one chatroom");//debug
                System.out.println(id);//debug
                System.out.println(name);//debug
            }

            System.out.println("adapter");//debug

            adapter = new ChatroomAdapter(MainActivity.this, R.layout.chatroom_item, chatroomList);
            chatroomListView = (ListView) findViewById(R.id.chat_list_view);
            chatroomListView.setAdapter(adapter);

            System.out.println("finish");//debug

        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    //主线程
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 绑定UI组件
        setContentView(R.layout.activity_main);

        //启动AsyncTask，手动调用execute(Params... params) 从而执行异步线程任务
        mTask = new MainTask();
        mTask.execute("http://34.196.30.102/api/a3/get_chatrooms");//已改为a3的URL


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
