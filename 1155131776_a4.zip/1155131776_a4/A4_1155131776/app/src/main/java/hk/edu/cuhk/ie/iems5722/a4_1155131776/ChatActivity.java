package hk.edu.cuhk.ie.iems5722.a4_1155131776;


import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.PendingIntent;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;


public class ChatActivity extends AppCompatActivity {

    RetriveTask rTask;
    PostTask pTask;
    int roomId;
    int total_pages;
    public static int page;//used in RetriveTask doInBackground(), default: 1st page
    String url_getMsg = "http://34.196.30.102/api/a3/get_messages";//已改为a3的URL
    String url_postMsg = "http://34.196.30.102/api/a3/send_message";//已改为a3的URL

    int user_id = 1155131776;//自定义
    String user_name = "ivy";//自定义
    String send_content = "";
    String roomName = "";
    String socket_message = "";
    List<String> nameList = new ArrayList<>();//定义一个list存放chatroomName

    private Socket socket;//A4 socket.io

    private ListView msgListView;
    private EditText inputText;
    private ImageButton sendBtn;// 发送按钮
    private MSGAdapter adapter;// 消息视图的Adapter
    private List<MSG> msgList = new ArrayList<MSG>();// 消息对象数组

    //创建AsyncTask子类,获取对应chatroom里的message
    private class RetriveTask extends AsyncTask<String,Integer,String> {

        //onPreExecute()执行线程任务前的操作
        @Override
        protected void onPreExecute() {
            inputText = (EditText)findViewById(R.id.input_text);
            sendBtn = (ImageButton)findViewById(R.id.send_btn);
        }

        //接收输入参数、执行任务中的耗时操作、返回 线程任务执行的结果
        @Override
        protected String doInBackground(String... strings) {
            //代表子线程
            //利用子线程请求数据
            System.out.println("page");//debug
            System.out.println(page);//debug
            return HTTP.requestHttpGetMSG(strings[0],roomId,page);//fetch the messages in page page of the selected chatroom
        }

        //接收线程任务执行结果、将执行结果显示到UI组件
        @Override
        protected void onPostExecute(String s) {
            System.out.println(s);
            getMsg(s);
        }
    }

    public void getMsg(String str) {

        try {
            JSONObject resJSON = new JSONObject(str);

            String status = resJSON.getString("status");

            JSONObject data = resJSON.getJSONObject("data");
            int current_page = data.getInt("current_page");
            total_pages = data.getInt("total_pages");
            System.out.println("total_pages");
            System.out.println(total_pages);
            JSONArray messages = data.getJSONArray("messages");

            List<String> message = new ArrayList<>();
            List<String> name = new ArrayList<>();
            List<String> message_time = new ArrayList<>();
            List<Integer> user_id = new ArrayList<>();

            for (int i = messages.length() - 1; i >= 0; i--) {//注意i的设置，从后往前取数据，使后面展示每页msg按其发送时间从旧到新（最新发送的msg在bottom

                JSONObject one_message = messages.getJSONObject(i);
                String msg = one_message.getString("message");
                message.add(msg);
                String n = one_message.getString("name");
                name.add(n);
                String t = one_message.getString("message_time");
                message_time.add(t);
                int u = one_message.getInt("user_id");
                user_id.add(u);

                System.out.println(msg);
                System.out.println(n);
                System.out.println(t);
                System.out.println(u);
                MSG m = new MSG(msg, n, t, u);
                msgList.add(m);
                adapter.notifyDataSetChanged();// 通知ListView，数据已发生改变
                msgListView.setSelection(adapter.getCount() - 1);///
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    //创建AsyncTask子类,把user输入的message提交到server
    private class PostTask extends AsyncTask<String,Integer,String> {

        //接收输入参数、执行任务中的耗时操作、返回 线程任务执行的结果
        @Override
        protected String doInBackground(String... strings) {
            //代表子线程
            //利用子线程post消息并return status
            return HTTP.requestHttpPost(strings[0],roomId,user_id,user_name,send_content);//fetch the messages in page page of the selected chatroom
        }

        //接收线程任务执行结果、将执行结果显示到UI组件
        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject resJSON = new JSONObject(s);
                String status = resJSON.getString("status");

                System.out.println(status);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Intent intent = getIntent();
        roomId = intent.getIntExtra("chatroomID",0);//接收整型数字除了写name，还要有个defaultValue 0
        roomName = intent.getStringExtra("chatroomName");
        nameList = (List<String>)intent.getSerializableExtra("nameList");//接收chatroom nameList给后面notification用
        System.out.println("NOW show chatroom");//debug
        System.out.println(roomId);//debug
        System.out.println(roomName);//debug
        System.out.println("------nameList");//debug
        System.out.println(nameList);//debug

        setTitle(roomName);//set activity label name as room name

//A4 socket.io
        try {
            socket = IO.socket("http://34.196.30.102:8001");//
            socket.on("response", onResponse);
            socket.connect();//Initiating a connection to the server
        } catch (
                URISyntaxException e) {
            e.printStackTrace();
        }

        if (socket != null) {
            try {
                JSONObject json = new JSONObject();
                json.put("username", user_name);
                json.put("chatroom_id", roomId);
                socket.emit("join", json);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }


        System.out.println("-------socket_message");//debug
        System.out.println(socket_message);//debug
        System.out.println("".equals(socket_message));//debug


//            if (!"".equals(socket_message)) {
//
//            }


//        System.out.println("cadapter");//debug

        adapter = new MSGAdapter(ChatActivity.this, R.layout.msg_item, msgList);
        msgListView = (ListView)findViewById(R.id.msg_list_view);
        msgListView.setAdapter(adapter);

//        System.out.println("cfinish");//debug

        page = 1;//used in RetriveTask doInBackground(), default: 1st page
        //启动AsyncTask，手动调用execute(Params... params) 从而执行异步线程任务
        rTask = new RetriveTask();
        rTask.execute(url_getMsg);//get previous messages

        msgListView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                switch (scrollState) {
                    //滚动结束
                    case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:
                        System.out.println("view.getLastVisiblePosition()");
                        System.out.println(view.getLastVisiblePosition());
                        System.out.println("view.getCount()");
                        System.out.println(view.getCount());
                        System.out.println("view.getFirstVisiblePosition()");
                        System.out.println(view.getFirstVisiblePosition());
                        //滚动停止时
                        if (view.getFirstVisiblePosition() == 0) {
                            //滚动到顶部,页数加1
                            page += 1;
                            if (page > total_pages) { page = total_pages;} //last page
                            Toast.makeText(ChatActivity.this,"page "+page,Toast.LENGTH_SHORT).show();//Toast 是一个 View 视图，快速的为用户显示少量的信息
                            rTask = new RetriveTask();//NEEDED cuz a task can be executed only once
                            rTask.execute(url_getMsg);//get messages// 刷新适配器
                            adapter.notifyDataSetChanged();
                            msgListView.setSelection(adapter.getCount()-1);///

                        } else if (view.getLastVisiblePosition() == view.getCount()-1) {

                            //滚动到底部,页数减1
                            page -= 1;
                            if (page == 0) { page = 1;}//first page
                            System.out.println("page");//debug
                            System.out.println(page);//debug
                            Toast.makeText(ChatActivity.this,"page "+page,Toast.LENGTH_SHORT).show();
                            rTask = new RetriveTask();//NEEDED cuz a task can be executed only once
                            rTask.execute(url_getMsg);//get messages
                            // 刷新适配器
                            adapter.notifyDataSetChanged();
                            msgListView.setSelection(adapter.getCount()-1);///

                        }
                        break;

                    //开始滚动
                    case AbsListView.OnScrollListener.SCROLL_STATE_FLING:
                        break;

                    //正在滚动
                    case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL:
                        break;

                    default:
                        break;
                }

            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                send_content = inputText.getText().toString();//get sent content
                String format_time = (String)(new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(new Date());//set time format, new Date()为获取当前系统时间
                if(!"".equals(send_content)) {
                    pTask = new PostTask();
                    pTask.execute(url_postMsg);//post message to the server

                    MSG msg = new MSG(send_content,user_name,format_time,MSG.TYPE_POST);///
                    msgList.add(msg);
                    adapter.notifyDataSetChanged();//刷新适配器,通知ListView，数据已发生改变
                    msgListView.setSelection(adapter.getCount()-1);///

                    inputText.setText("");// 清空编辑框数据
                }
            }
        });
    }


    @Override
    protected void onDestroy() {
        if (socket != null) {
            socket.disconnect();
            socket.off();
        }
        super.onDestroy();
    }

    private Emitter.Listener onResponse = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            try {
                System.out.println("--------response1");//debug
                JSONObject data = (JSONObject) args[0];
                System.out.println(data);//debug
                final String socket_message = data.getString("message");
                int chatroom_id = data.getInt("chatroom_id");
                final String chatroom_name = nameList.get(chatroom_id-1);//list下标从0开始
                System.out.println(nameList.get(0));//debug
                System.out.println(nameList.get(1));//debug
                System.out.println(nameList.get(2));//debug
                System.out.println(socket_message);//debug
                System.out.println(chatroom_name);//debug
                System.out.println(chatroom_id);//debug
                System.out.println("--------response2");//debug

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//A4 notification
                        int notificationId = 0;///
                        System.out.println("--------notification1");//debug

                        String CHANNEL_ID = "1";///
                        notificationId++;
                        Uri sound= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);


                        NotificationCompat.Builder builder = new NotificationCompat.Builder(ChatActivity.this.getApplicationContext(), CHANNEL_ID)
                                .setSound(sound)
                                .setSmallIcon(R.drawable.notification_icon)
                                .setContentTitle(chatroom_name)
                                .setContentText(socket_message)
                                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

                        System.out.println("--------notification2");//debug

                        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(ChatActivity.this.getApplicationContext());
                        // notificationId is a unique int for each notification that you must define
                        notificationManager.notify(notificationId, builder.build());


                        System.out.println("--------notification3");//debug

                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_chat, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_refresh) { //click the refresh button
            System.out.println("refresh");

            //reset the page to fetch the 1st page msg
            page = 1;
            msgList.clear();///
            //启动AsyncTask，手动调用execute(Params... params) 从而执行异步线程任务
            rTask = new RetriveTask();
            rTask.execute(url_getMsg);//get messages
            Toast.makeText(ChatActivity.this,"page "+page,Toast.LENGTH_SHORT).show();
            // 刷新适配器
            adapter.notifyDataSetChanged();
            msgListView.setSelection(adapter.getCount()-1);///
        }

        return super.onOptionsItemSelected(item);
    }

}

