package hk.edu.cuhk.ie.iems5722.a4_1155131776;

import android.net.Uri;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class HTTP {

    /**
     * 请求数据GET请求
     */
    public static String requestHttpGet(String strUrl) {

        try {
            URL urlGet = new URL(strUrl); //设置url
            HttpURLConnection connGet = (HttpURLConnection) urlGet.openConnection();
            connGet.setReadTimeout(10000);
            connGet.setConnectTimeout(15000);
            connGet.setRequestMethod("GET");
            connGet.setDoInput(true);
            //Start the query
            connGet.connect();
            int response = connGet.getResponseCode(); //200 if successful

            if (response == HttpURLConnection.HTTP_OK) {
                //如果数据请求成功
                //就获取数据
                InputStream is = connGet.getInputStream();

                //convert the InputStream into a string
                String result = "";
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                while ((line = br.readLine()) != null) {
                    result += line;
                }

                return result;
            }
            //关闭连接
            connGet.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 请求消息GET请求
     */
    public static String requestHttpGetMSG(String strUrl, int chatroom_id, int page) {

        try {
            URL urlGet = new URL(strUrl+"?chatroom_id="+chatroom_id+"&page="+page); //设置url
            HttpURLConnection connGet = (HttpURLConnection) urlGet.openConnection();
            connGet.setReadTimeout(10000);
            connGet.setConnectTimeout(15000);
            connGet.setRequestMethod("GET");
            connGet.setDoInput(true);
            //Start the query
            connGet.connect();
            int response = connGet.getResponseCode(); //200 if successful

            System.out.println("GET MSG response");
            System.out.println(response);

            if (response == HttpURLConnection.HTTP_OK) {
                //如果数据请求成功
                //就获取数据
                InputStream is = connGet.getInputStream();

                //convert the InputStream into a string
                String result = "";
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                while ((line = br.readLine()) != null) {
                    result += line;
                }

                return result;
            }
            //关闭连接
            connGet.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 请求消息POST请求
     */
    public static String requestHttpPost(String strUrl, int chatroom_id, int user_id, String name, String message) {

        try {
            URL urlPost = new URL(strUrl); //设置url
            HttpURLConnection connPost = (HttpURLConnection) urlPost.openConnection();
            connPost.setReadTimeout(15000);
            connPost.setConnectTimeout(15000);
            connPost.setRequestMethod("POST");
            connPost.setDoInput(true);
            connPost.setDoOutput(true);

            OutputStream os = connPost.getOutputStream();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));
            Uri.Builder builder = new Uri.Builder();
            // Build the parameters using ArrayList objects para_names and para_values
            builder.appendQueryParameter("chatroom_id",Integer.toString(chatroom_id));
            builder.appendQueryParameter("user_id",Integer.toString(user_id));
            builder.appendQueryParameter("name",name);
            builder.appendQueryParameter("message",message);
            String query = builder.build().getEncodedQuery();

            writer.write(query);
            System.out.println("query");
            System.out.println(query);

            writer.flush();
            writer.close();
            os.close();

            int responseCode = connPost.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                //如果数据请求成功
                //就获取status
                InputStream is = connPost.getInputStream();

                //convert the InputStream into a string
                String result = "";
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(is));
                while ((line = br.readLine()) != null) {
                    result += line;
                }

                return result;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}


