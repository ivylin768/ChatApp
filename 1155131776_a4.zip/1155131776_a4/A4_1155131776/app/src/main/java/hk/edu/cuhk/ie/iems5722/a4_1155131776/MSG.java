package hk.edu.cuhk.ie.iems5722.a4_1155131776;

public class MSG {
    public static final int TYPE_POST = 1155131776; //user id of sent msg

    private String content;//消息内容,即message
    private String name;//sender name
    private String time;//消息日期
    private int type;//消息类型（发送的or接收到的）

    public MSG (String content, String name, String time, int type) {
        this.content = content;
        this.name = name;
        this.time = time;
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public String getName() {
        return "User: "+name;//字符串拼接
    }

    public String getDate() {
        return time;
    }

    public int getType() { return type; }
}
