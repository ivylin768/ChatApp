from flask import Flask, request, jsonify
from flask_socketio import SocketIO, emit, join_room, leave_room

app = Flask(__name__)
app.config['SECRET_KEY'] = 'iems5722'
socketio = SocketIO(app)

@app.route("/api/a4/broadcast_room", methods=["POST"])
def broadcast_room():
    print("broadcast")
    chatroom_id = int(request.form.get("chatroom_id"))
    message = request.form.get("message")
    print(chatroom_id,message)
    print("broadcast request received")
    if(chatroom_id is None or message is None):  # check if any parameter is missing
        return jsonify(message="<error message>", status="ERROR")
    else:
        # broadcast a socket.io message to all clients connected to a specific chatroom
        #socket_message = "Received A New Message!"
        socketio.emit('response',{'message':message,'chatroom_id':chatroom_id},chatroom_id=chatroom_id)
        return jsonify(status="OK")
    


# Invoked whenever a client is connected
@socketio.on('connect')
def connect_handler():
    print('Client connected')

# Invoked whenever a client is disconnected
@socketio.on('disconnect')
def disconnect_handler():
    print('Client disconnected')

@socketio.on('join')
def on_join(data):
    print("join",str(data))
    # username = ['username']
    chatroom_id = data['chatroom_id']
    join_room(chatroom_id)

@socketio.on('leave')
def on_leave(data):
    print("leave")
    # username = ['username']
    chatroom_id = data['chatroom_id']
    leave_room(chatroom_id)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=8001, debug=True)

