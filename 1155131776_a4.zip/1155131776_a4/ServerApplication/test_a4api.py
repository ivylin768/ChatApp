import requests

chatroom_id = 1
message = "hi"

a4api = "http://localhost:8001/api/a4/broadcast_room"
a4api_input = {"chatroom_id":chatroom_id,"message":message}
r = requests.post(a4api,data=a4api_input)##
if r.status_code == 200:
    print("Broadcast Room API in assign is called successfully!")
else:
    print(r.text)
